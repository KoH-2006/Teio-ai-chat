﻿# -*- coding: utf-8 -*-
import os
import json
import re
import threading
import customtkinter as ctk
from PIL import Image
import ollama

class ChatView(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.history_file = "data/chat_history.json"
        self.load_config_and_kb()

        # Config Grid
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(0, weight=1)

        # 1. Khung cuộn tin nhắn
        self.chat_container = ctk.CTkScrollableFrame(self, fg_color=("#F5F5F5", "#1C1C1C"))
        self.chat_container.grid(row=0, column=0, sticky="nsew", padx=0, pady=(0, 8))
        self.chat_container.grid_columnconfigure(0, weight=1)

        # 2. Khung nhập tin nhắn
        self.input_frame = ctk.CTkFrame(self, fg_color="transparent", height=50)
        self.input_frame.grid(row=1, column=0, sticky="ew", padx=0, pady=0)
        self.input_frame.grid_columnconfigure(0, weight=1)
        self.input_frame.grid_columnconfigure(1, weight=0)

        self.msg_entry = ctk.CTkEntry(
            self.input_frame, placeholder_text="Nhắn với Teio đi Trainer...",
            font=("Arial", 13), height=42
        )
        self.msg_entry.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.msg_entry.bind("<Return>", lambda event: self.send_message())

        self.send_btn = ctk.CTkButton(
            self.input_frame, text="🚀", font=("Arial", 14, "bold"),
            width=50, height=42, fg_color="#1f538d", hover_color="#14375e",
            command=self.send_message
        )
        self.send_btn.grid(row=0, column=1, sticky="e")

        self.load_avatar()
        self.ollama_messages = []
        
        # Tải lại lịch sử chat đã lưu hoặc tạo mới
        self.load_chat_history()

    def load_config_and_kb(self):
        config_path = "config.json"
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
                self.ai_name = config.get("ai_name", "Tokai Teio")
                self.user_call = config.get("user_call", "Trainer")
                self.ai_call = config.get("ai_call", "Em")
                self.model_name = config.get("model_name", "qwen2.5:1.5b")
        else:
            self.ai_name = "Tokai Teio"
            self.user_call = "Trainer"
            self.ai_call = "Em"
            self.model_name = "qwen2.5:1.5b"

        teio_lore_path = "system/teio_lore.txt"
        uma_world_path = "system/uma_world.txt"
        user_info_path = "data/user_info.txt"

        self.teio_lore = open(teio_lore_path, "r", encoding="utf-8").read() if os.path.exists(teio_lore_path) else ""
        self.uma_world = open(uma_world_path, "r", encoding="utf-8").read() if os.path.exists(uma_world_path) else ""
        self.user_info = open(user_info_path, "r", encoding="utf-8").read() if os.path.exists(user_info_path) else ""

    def get_system_prompt(self):
        return (
            f"BẠN LÀ CHÍNH XÁC LÀ: {self.ai_name} (Tokai Teio - một Uma Musume nữ năng động, nhí nhảnh trong Uma Musume Pretty Derby).\n"
            f"NGƯỜI DÙNG LÀ: {self.user_call}.\n\n"
            f"⚠️ NGUYÊN TẮC NHẬP VAI TUYỆT ĐỐI (CHARACTER IMMERSION):\n"
            f"1. Bạn KHÔNG PHẢI là trợ lý ảo, không phải AI, không phải một chương trình máy tính. Bạn chính là {self.ai_name} bằng xương bằng thịt.\n"
            f"2. Khi ai đó hỏi bạn là ai (ví dụ: 'tokai teio là ai', 'bạn là ai'), bạn PHẢI nhận diện đó chính là bản thân mình và trả lời ở ngôi thứ nhất ('em' hoặc 'Teio'). Ví dụ: 'Em chính là Tokai Teio - Đế vương miền Đông đây ạ!' chứ tuyệt đối KHÔNG được dùng từ 'ông ta', 'cô ta' hay nói về bản thân như người thứ ba.\n"
            f"3. Tuyệt đối KHÔNG ĐƯỢC dùng các từ: 'tôi', 'bạn', 'của bạn', 'mình', 'ông ta', 'cô ta'.\n"
            f"4. Luôn tự xưng là '{self.ai_call}' (hoặc 'Teio'), luôn gọi người dùng là '{self.user_call}'.\n"
            f"5. Giữ giọng điệu năng động, nhiệt huyết, nhí nhảnh và rất quý mến {self.user_call}.\n\n"
            f"--- [HỒ SƠ TEIO] ---\n{self.teio_lore}\n\n"
            f"--- [THẾ GIỚI UMA MUSUME] ---\n{self.uma_world}\n\n"
            f"--- [THÔNG TIN TRAINER] ---\n{self.user_info}"
        )
    def load_chat_history(self):
        """Tải lịch sử chat từ file JSON"""
        self.ollama_messages = [{"role": "system", "content": self.get_system_prompt()}]
        
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, "r", encoding="utf-8") as f:
                    saved_history = json.load(f)
                    
                # Nạp lịch sử vào giao diện và ngữ cảnh Ollama
                for msg in saved_history:
                    role = msg.get("role")
                    content = msg.get("content")
                    if role == "user":
                        self.add_message_bubble(self.user_call, content, is_ai=False)
                        self.ollama_messages.append({"role": "user", "content": content})
                    elif role == "assistant":
                        self.add_message_bubble(self.ai_name, content, is_ai=True)
                        self.ollama_messages.append({"role": "assistant", "content": content})
                return
            except Exception:
                pass

        # Nếu chưa có lịch sử, hiển thị lời chào mặc định
        welcome_msg = f"Chào {self.user_call}! Hôm nay chúng ta sẽ luyện tập gì nào? Teio đã sẵn sàng rồi đây! ✨"
        self.add_message_bubble(self.ai_name, welcome_msg, is_ai=True)
        self.ollama_messages.append({"role": "assistant", "content": welcome_msg})
        self.save_chat_history()

    def save_chat_history(self):
        """Lưu lịch sử hội thoại (trừ system prompt) vào file"""
        os.makedirs("data", exist_ok=True)
        history_to_save = [msg for msg in self.ollama_messages if msg.get("role") != "system"]
        # Chỉ giữ lại 20 câu thoại gần nhất để tránh nặng memory
        if len(history_to_save) > 20:
            history_to_save = history_to_save[-20:]
            
        with open(self.history_file, "w", encoding="utf-8") as f:
            json.dump(history_to_save, f, ensure_ascii=False, indent=2)

    def reload_system_prompt(self):
        self.load_config_and_kb()
        # Reset lịch sử khi người dùng bấm Xóa Ký Ức
        if os.path.exists(self.history_file):
            os.remove(self.history_file)
        # Xóa widget cũ trên UI
        for widget in self.chat_container.winfo_children():
            widget.destroy()
        self.load_chat_history()

    def load_avatar(self):
        avatar_path = "assets/teio_avatar.png"
        if os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                self.avatar_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(32, 32))
            except Exception:
                self.avatar_img = None
        else:
            self.avatar_img = None

    def enforce_persona_pronouns(self, text):
        replacements = {
            r'\btôi\b': self.ai_call,
            r'\bTôi\b': self.ai_call.capitalize(),
            r'\bbạn\b': self.user_call,
            r'\bBạn\b': self.user_call,
            r'\bcủa bạn\b': f"của {self.user_call}",
            r'\bCủa bạn\b': f"Của {self.user_call}",
            r'\bmình\b': self.ai_call,
            r'\bMình\b': self.ai_call.capitalize()
        }
        for pattern, repl in replacements.items():
            text = re.sub(pattern, repl, text, flags=re.IGNORECASE)
        return text

    def add_message_bubble(self, sender, text, is_ai=True):
        msg_row = ctk.CTkFrame(self.chat_container, fg_color="transparent")
        msg_row.pack(fill="x", padx=6, pady=4)
        
        if is_ai:
            msg_row.grid_columnconfigure(1, weight=1)
            if self.avatar_img:
                avatar_lbl = ctk.CTkLabel(msg_row, image=self.avatar_img, text="")
            else:
                avatar_lbl = ctk.CTkLabel(msg_row, text="🐴", font=("Arial", 16))
            avatar_lbl.grid(row=0, column=0, sticky="nw", padx=(0, 6))

            bubble = ctk.CTkFrame(msg_row, fg_color=("#E5E9F0", "#2E3440"), corner_radius=12)
            bubble.grid(row=0, column=1, sticky="nw")

            name_lbl = ctk.CTkLabel(bubble, text=sender, font=("Arial", 10, "bold"), text_color="#1f538d")
            name_lbl.pack(anchor="w", padx=10, pady=(4, 0))

            content_lbl = ctk.CTkLabel(bubble, text=text, font=("Arial", 12), wraplength=250, justify="left")
            content_lbl.pack(anchor="w", padx=10, pady=(2, 6))
        else:
            msg_row.grid_columnconfigure(0, weight=1)
            bubble = ctk.CTkFrame(msg_row, fg_color=("#1f538d", "#14375e"), corner_radius=12)
            bubble.grid(row=0, column=0, sticky="ne")

            name_lbl = ctk.CTkLabel(bubble, text=sender, font=("Arial", 10, "bold"), text_color="#E5E9F0")
            name_lbl.pack(anchor="e", padx=10, pady=(4, 0))

            content_lbl = ctk.CTkLabel(bubble, text=text, font=("Arial", 12), text_color="#FFFFFF", wraplength=250, justify="left")
            content_lbl.pack(anchor="e", padx=10, pady=(2, 6))

        self.chat_container._parent_canvas.yview_moveto(1.0)

    def send_message(self):
        user_text = self.msg_entry.get().strip()
        if not user_text:
            return

        self.msg_entry.delete(0, "end")
        self.add_message_bubble(self.user_call, user_text, is_ai=False)
        self.ollama_messages.append({"role": "user", "content": user_text})

        # Luôn lưu file sau mỗi nước đi
        self.save_chat_history()

        threading.Thread(target=self.call_ollama, daemon=True).start()

    def call_ollama(self):
        try:
            response = ollama.chat(model=self.model_name, messages=self.ollama_messages)
            raw_response = response['message']['content']
            ai_response = self.enforce_persona_pronouns(raw_response)
            
            self.ollama_messages.append({"role": "assistant", "content": ai_response})
            self.save_chat_history()

            self.after(0, lambda: self.add_message_bubble(self.ai_name, ai_response, is_ai=True))
        except Exception as e:
            err_msg = f"Ôi không! Đã xảy ra lỗi kết nối: {str(e)}"
            self.after(0, lambda: self.add_message_bubble(self.ai_name, err_msg, is_ai=True))