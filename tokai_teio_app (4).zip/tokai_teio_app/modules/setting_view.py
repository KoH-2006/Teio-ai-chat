﻿# -*- coding: utf-8 -*-
import os
import json
import customtkinter as ctk

class SettingView(ctk.CTkFrame):
    def __init__(self, master, on_save_callback=None, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.on_save_callback = on_save_callback

        self.load_config()
        self.load_user_info()

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.scroll_container = ctk.CTkScrollableFrame(self, fg_color=("#F8F9FA", "#181818"))
        self.scroll_container.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        self.scroll_container.grid_columnconfigure(0, weight=1)

        # ================= SECTION 1: CẤU HÌNH HỆ THỐNG & XƯNG HÔ =================
        self.config_card = ctk.CTkFrame(self.scroll_container, fg_color=("#E5E9F0", "#2E3440"), corner_radius=12)
        self.config_card.pack(fill="x", padx=5, pady=(5, 10))
        self.config_card.grid_columnconfigure(0, weight=1)

        card_title = ctk.CTkLabel(self.config_card, text="⚙️ Thiết Lập Hệ Thống & Xưng Hô", font=("Arial", 14, "bold"), text_color="#1f538d")
        card_title.grid(row=0, column=0, padx=12, pady=(12, 8), sticky="w")

        ctk.CTkLabel(self.config_card, text="Tên AI:", font=("Arial", 11, "bold")).grid(row=1, column=0, padx=12, pady=(4, 2), sticky="w")
        self.ai_name_entry = ctk.CTkEntry(self.config_card, font=("Arial", 12), height=35)
        self.ai_name_entry.grid(row=2, column=0, padx=12, pady=(0, 8), sticky="ew")
        self.ai_name_entry.insert(0, self.config_data.get("ai_name", "Tokai Teio"))

        ctk.CTkLabel(self.config_card, text="Cách gọi User (Trainer):", font=("Arial", 11, "bold")).grid(row=3, column=0, padx=12, pady=(4, 2), sticky="w")
        self.user_call_entry = ctk.CTkEntry(self.config_card, font=("Arial", 12), height=35)
        self.user_call_entry.grid(row=4, column=0, padx=12, pady=(0, 8), sticky="ew")
        self.user_call_entry.insert(0, self.config_data.get("user_call", "Trainer"))

        ctk.CTkLabel(self.config_card, text="AI tự xưng:", font=("Arial", 11, "bold")).grid(row=5, column=0, padx=12, pady=(4, 2), sticky="w")
        self.ai_call_entry = ctk.CTkEntry(self.config_card, font=("Arial", 12), height=35)
        self.ai_call_entry.grid(row=6, column=0, padx=12, pady=(0, 8), sticky="ew")
        self.ai_call_entry.insert(0, self.config_data.get("ai_call", "Em"))

        ctk.CTkLabel(self.config_card, text="Model Ollama:", font=("Arial", 11, "bold")).grid(row=7, column=0, padx=12, pady=(4, 2), sticky="w")
        self.model_entry = ctk.CTkEntry(self.config_card, font=("Arial", 12), height=35)
        self.model_entry.grid(row=8, column=0, padx=12, pady=(0, 12), sticky="ew")
        self.model_entry.insert(0, self.config_data.get("model_name", "qwen2.5:1.5b"))

        btn_grid = ctk.CTkFrame(self.config_card, fg_color="transparent")
        btn_grid.grid(row=9, column=0, padx=12, pady=(0, 12), sticky="ew")
        btn_grid.grid_columnconfigure((0, 1), weight=1)

        self.save_btn = ctk.CTkButton(
            btn_grid, text="💾 Lưu Cấu Hình", font=("Arial", 12, "bold"),
            height=38, fg_color="#2ecc71", hover_color="#27ae60", command=self.save_config
        )
        self.save_btn.grid(row=0, column=0, padx=(0, 4), sticky="ew")

        self.clear_mem_btn = ctk.CTkButton(
            btn_grid, text="🧹 Xóa Ký Ức AI", font=("Arial", 12, "bold"),
            height=38, fg_color="#e67e22", hover_color="#d35400", command=self.clear_memory
        )
        self.clear_mem_btn.grid(row=0, column=1, padx=(4, 0), sticky="ew")

        self.status_lbl = ctk.CTkLabel(self.config_card, text="", font=("Arial", 11, "italic"), text_color="#27ae60")
        self.status_lbl.grid(row=10, column=0, padx=12, pady=(0, 10))


        # ================= SECTION 2: USER INFO EDITOR (THAY CHO KNOWLEDGE BASE) =================
        self.user_card = ctk.CTkFrame(self.scroll_container, fg_color=("#ECEFF4", "#242933"), corner_radius=12)
        self.user_card.pack(fill="x", padx=5, pady=(0, 10))
        self.user_card.grid_columnconfigure(0, weight=1)

        user_title = ctk.CTkLabel(self.user_card, text="👤 Thông Tin Riêng / Ghi Chú của Trainer", font=("Arial", 14, "bold"), text_color="#5E81AC")
        user_title.grid(row=0, column=0, padx=12, pady=(12, 8), sticky="w")

        self.user_textbox = ctk.CTkTextbox(self.user_card, font=("Consolas", 11), height=180, wrap="word", fg_color=("#FFFFFF", "#2E3440"))
        self.user_textbox.grid(row=1, column=0, padx=12, pady=(0, 10), sticky="ew")
        self.user_textbox.insert("1.0", self.user_info_content)

        self.save_user_btn = ctk.CTkButton(
            self.user_card, text="💾 Lưu Thông Tin Trainer", font=("Arial", 12, "bold"),
            height=38, fg_color="#1f538d", hover_color="#14375e", command=self.save_user_info
        )
        self.save_user_btn.grid(row=2, column=0, padx=12, pady=(0, 12), sticky="ew")

    def load_config(self):
        config_path = "config.json"
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                self.config_data = json.load(f)
        else:
            self.config_data = {
                "ai_name": "Tokai Teio",
                "user_call": "Trainer",
                "ai_call": "Em",
                "model_name": "qwen2.5:1.5b"
            }

    def load_user_info(self):
        user_path = "data/user_info.txt"
        if os.path.exists(user_path):
            with open(user_path, "r", encoding="utf-8") as f:
                self.user_info_content = f.read()
        else:
            self.user_info_content = "Chưa có thông tin riêng."

    def save_config(self):
        self.config_data["ai_name"] = self.ai_name_entry.get().strip()
        self.config_data["user_call"] = self.user_call_entry.get().strip()
        self.config_data["ai_call"] = self.ai_call_entry.get().strip()
        self.config_data["model_name"] = self.model_entry.get().strip()

        with open("config.json", "w", encoding="utf-8") as f:
            json.dump(self.config_data, f, ensure_ascii=False, indent=4)

        self.status_lbl.configure(text="Đã lưu cấu hình thành công! ✨", text_color="#27ae60")
        if self.on_save_callback:
            self.on_save_callback()

    def save_user_info(self):
        new_content = self.user_textbox.get("1.0", "end-1c")
        os.makedirs("data", exist_ok=True)
        with open("data/user_info.txt", "w", encoding="utf-8") as f:
            f.write(new_content)

        self.status_lbl.configure(text="Đã cập nhật thông tin Trainer! 🚀", text_color="#27ae60")
        if self.on_save_callback:
            self.on_save_callback()

    def clear_memory(self):
        self.status_lbl.configure(text="Đã xóa ký ức ngắn hạn của AI! 🧹", text_color="#e67e22")
        if self.on_save_callback:
            self.on_save_callback()