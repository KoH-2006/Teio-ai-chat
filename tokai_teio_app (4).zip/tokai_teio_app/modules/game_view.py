﻿# -*- coding: utf-8 -*-
import customtkinter as ctk
import os
# Import các game
from .game_caro import CaroGame 
from .game_flappy import FlappyTeio 

class GameView(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.grid(row=0, column=0, sticky="nsew")
        self.container.grid_columnconfigure(0, weight=1)
        self.container.grid_rowconfigure(0, weight=1)

        self.show_game_menu()

    def clear_container(self):
        for widget in self.container.winfo_children():
            widget.destroy()

    def show_game_menu(self):
        self.clear_container()

        title = ctk.CTkLabel(
            self.container, text="🎮 Trung Tâm Giải Trí Của Teio", 
            font=("Arial", 18, "bold"), text_color="#1f538d"
        )
        title.pack(pady=(20, 20))

        self.menu_frame = ctk.CTkScrollableFrame(self.container, fg_color="transparent")
        self.menu_frame.pack(fill="both", expand=True, padx=20, pady=10)
        self.menu_frame.grid_columnconfigure(0, weight=1)

        self.create_game_card(
            "❌ Cờ Caro 10x10", 
            "Thử thách trí tuệ cùng Teio trên bàn cờ rộng.", 
            "#1f538d", 
            self.start_caro
        )

        self.create_game_card(
            "🐴 Flappy Teio", 
            "Giúp Teio bay qua các chướng ngại vật, ăn cà rốt và tránh Mambo!", 
            "#ff6b6b", 
            self.start_flappy
        )

    def create_game_card(self, title, desc, color, command):
        card = ctk.CTkFrame(
            self.menu_frame, fg_color=("#FFFFFF", "#2E3440"), 
            border_width=2, border_color=color, corner_radius=15
        )
        card.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(card, text=title, font=("Arial", 15, "bold"), text_color=color).pack(anchor="w", padx=15, pady=(12, 2))
        ctk.CTkLabel(card, text=desc, font=("Arial", 12), text_color=("#666666", "#AAAAAA"), 
                    wraplength=300, justify="left").pack(anchor="w", padx=15, pady=(0, 12))

        btn_play = ctk.CTkButton(
            card, text="Chơi Ngay 🚀", font=("Arial", 12, "bold"),
            fg_color=color, width=100, height=32, command=command
        )
        btn_play.pack(anchor="e", padx=15, pady=(0, 12))

    def start_caro(self):
        self.clear_container()
        self.caro_game = CaroGame(self.container, back_callback=self.show_game_menu)
        self.caro_game.pack(fill="both", expand=True)

    def start_flappy(self):
        """Khởi chạy Flappy Teio trực tiếp trong khung giao diện ứng dụng"""
        self.clear_container()
        self.flappy_game = FlappyTeio(self.container, back_callback=self.show_game_menu)
        self.flappy_game.pack(fill="both", expand=True)