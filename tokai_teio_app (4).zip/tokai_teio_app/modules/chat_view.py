﻿# -*- coding: utf-8 -*-
import os
import json
import re
import threading
import customtkinter as ctk
from PIL import Image
import ollama

class ChatView(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.history_file = "data/chat_history.json"
        self.load_config_and_kb()

        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)
        self.grid_columnconfigure(0, weight=1)

        self.chat_container = ctk.CTkScrollableFrame(self, fg_color=("#F5F5F5", "#1C1C1C"))
        self.chat_container.grid(row=0, column=0, sticky="nsew", padx=0, pady=(0, 8))
        self.chat_container.grid_columnconfigure(0, weight=1)

        self.input_frame = ctk.CTkFrame(self, fg_color="transparent", height=50)
        self.input_frame.grid(row=1, column=0, sticky="ew", padx=0, pady=0)
        self.input_frame.grid_columnconfigure(0, weight=1)
        self.input_frame.grid_columnconfigure(1, weight=0)

        self.msg_entry = ctk.CTkEntry(
            self.input_frame, placeholder_text="Nhắn với Teio đi Trainer...",
            font=("Arial", 13), height=42
        )
        self.msg_entry.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.msg_entry.bind("<Return>", lambda event: self.send_message())

        self.send_btn = ctk.CTkButton(
            self.input_frame, text="🚀", font=("Arial", 14, "bold"),
            width=50, height=42, fg_color="#1f538d", hover_color="#14375e",
            command=self.send_message
        )
        self.send_btn.grid(row=0, column=1, sticky="e")

        self.load_avatar()
        self.ollama_messages = []
        self.load_chat_history()

    def load_config_and_kb(self):
        config_path = "config.json"
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
                self.ai_name = config.get("ai_name", "Tokai Teio")
                self.user_call = config.get("user_call", "Trainer")
                self.ai_call = config.get("ai_call", "Em")
                self.model_name = config.get("model_name", "qwen2.5:1.5b")
        else:
            self.ai_name, self.user_call, self.ai_call, self.model_name = "Tokai Teio", "Trainer", "Em", "qwen2.5:1.5b"

        teio_lore_path = "system/teio_lore.txt"
        uma_world_path = "system/uma_world.txt"
        user_info_path = "data/user_info.txt"
        self.teio_lore = open(teio_lore_path, "r", encoding="utf-8").read() if os.path.exists(teio_lore_path) else ""
        self.uma_world = open(uma_world_path, "r", encoding="utf-8").read() if os.path.exists(uma_world_path) else ""
        self.user_info = open(user_info_path, "r", encoding="utf-8").read() if os.path.exists(user_info_path) else ""

    def get_system_prompt(self):
        return (f"BẠN LÀ: {self.ai_name} (Tokai Teio). NGƯỜI DÙNG LÀ: {self.user_call}.\n"
                f"LUÔN tự xưng '{self.ai_call}', gọi người dùng là '{self.user_call}'.\n"
                f"Giọng điệu năng động, nhí nhảnh. KHÔNG dùng 'tôi/bạn'.\n\n"
                f"LORE: {self.teio_lore}\nWORLD: {self.uma_world}\nUSER: {self.user_info}")

    def load_chat_history(self):
        self.ollama_messages = [{"role": "system", "content": self.get_system_prompt()}]
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, "r", encoding="utf-8") as f:
                    saved_history = json.load(f)
                for msg in saved_history:
                    role, content = msg.get("role"), msg.get("content")
                    if role == "user":
                        self.add_message_bubble(self.user_call, content, is_ai=False)
                        self.ollama_messages.append({"role": "user", "content": content})
                    elif role == "assistant":
                        self.add_message_bubble(self.ai_name, content, is_ai=True)
                        self.ollama_messages.append({"role": "assistant", "content": content})
                return
            except Exception: pass
        
        welcome_msg = f"Chào {self.user_call}! Hôm nay chúng ta sẽ luyện tập gì nào? Teio đã sẵn sàng rồi đây! ✨"
        self.add_message_bubble(self.ai_name, welcome_msg, is_ai=True)
        self.ollama_messages.append({"role": "assistant", "content": welcome_msg})
        self.save_chat_history()

    def save_chat_history(self):
        os.makedirs("data", exist_ok=True)
        history_to_save = [msg for msg in self.ollama_messages if msg.get("role") != "system"][-20:]
        with open(self.history_file, "w", encoding="utf-8") as f:
            json.dump(history_to_save, f, ensure_ascii=False, indent=2)

    def reload_system_prompt(self):
        self.load_config_and_kb()
        if os.path.exists(self.history_file):
            os.remove(self.history_file)
        
        # Reset cuộn lên đầu trang
        self.chat_container._parent_canvas.yview_moveto(0.0)
        
        for widget in self.chat_container.winfo_children():
            widget.destroy()
        self.load_chat_history()

    def load_avatar(self):
        avatar_path = "assets/teio_avatar.png"
        if os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                self.avatar_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(32, 32))
            except Exception: self.avatar_img = None
        else: self.avatar_img = None

    def enforce_persona_pronouns(self, text):
        replacements = {r'\btôi\b': self.ai_call, r'\bBạn\b': self.user_call, r'\bbạn\b': self.user_call}
        for pattern, repl in replacements.items():
            text = re.sub(pattern, repl, text, flags=re.IGNORECASE)
        return text

    def add_message_bubble(self, sender, text, is_ai=True):
        msg_row = ctk.CTkFrame(self.chat_container, fg_color="transparent")
        msg_row.pack(fill="x", padx=6, pady=4)
        
        if is_ai:
            msg_row.grid_columnconfigure(1, weight=1)
            avatar_lbl = ctk.CTkLabel(msg_row, image=self.avatar_img, text="" if self.avatar_img else "🐴")
            avatar_lbl.grid(row=0, column=0, sticky="nw", padx=(0, 6))
            bubble = ctk.CTkFrame(msg_row, fg_color=("#E5E9F0", "#2E3440"), corner_radius=12)
            bubble.grid(row=0, column=1, sticky="nw")
            ctk.CTkLabel(bubble, text=sender, font=("Arial", 10, "bold"), text_color="#1f538d").pack(anchor="w", padx=10, pady=(4, 0))
            ctk.CTkLabel(bubble, text=text, font=("Arial", 12), wraplength=250, justify="left").pack(anchor="w", padx=10, pady=(2, 6))
        else:
            msg_row.grid_columnconfigure(0, weight=1)
            bubble = ctk.CTkFrame(msg_row, fg_color=("#1f538d", "#14375e"), corner_radius=12)
            bubble.grid(row=0, column=0, sticky="ne")
            ctk.CTkLabel(bubble, text=sender, font=("Arial", 10, "bold"), text_color="#E5E9F0").pack(anchor="e", padx=10, pady=(4, 0))
            ctk.CTkLabel(bubble, text=text, font=("Arial", 12), text_color="#FFFFFF", wraplength=250, justify="left").pack(anchor="e", padx=10, pady=(2, 6))

        # Tự động cuộn xuống cuối sau khi UI render
        self.after(10, lambda: self.chat_container._parent_canvas.yview_moveto(1.0))

    def send_message(self):
        user_text = self.msg_entry.get().strip()
        if not user_text: return
        self.msg_entry.delete(0, "end")
        self.add_message_bubble(self.user_call, user_text, is_ai=False)
        self.ollama_messages.append({"role": "user", "content": user_text})
        self.save_chat_history()
        threading.Thread(target=self.call_ollama, daemon=True).start()

    def call_ollama(self):
        try:
            response = ollama.chat(model=self.model_name, messages=self.ollama_messages)
            ai_response = self.enforce_persona_pronouns(response['message']['content'])
            self.ollama_messages.append({"role": "assistant", "content": ai_response})
            self.save_chat_history()
            self.after(0, lambda: self.add_message_bubble(self.ai_name, ai_response, is_ai=True))
        except Exception as e:
            self.after(0, lambda: self.add_message_bubble(self.ai_name, f"Lỗi kết nối: {str(e)}", is_ai=True))
