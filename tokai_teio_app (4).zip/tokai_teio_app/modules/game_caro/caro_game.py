# -*- coding: utf-8 -*-
import random
import os
import customtkinter as ctk
from PIL import Image

class CaroGame(ctk.CTkFrame):
    def __init__(self, master, back_callback, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.back_callback = back_callback 

        self.size = 10
        self.win_streak = 5
        self.board = [""] * (self.size * self.size)
        self.human = "❌"
        self.ai = "⭕"
        self.game_over = False

        self.grid_rowconfigure(0, weight=0) 
        self.grid_rowconfigure(1, weight=0) 
        self.grid_rowconfigure(2, weight=0) 
        self.grid_rowconfigure(3, weight=1) 
        self.grid_rowconfigure(4, weight=0) 
        self.grid_columnconfigure(0, weight=1)

        self.btn_back = ctk.CTkButton(
            self, text="⬅ Quay lại Menu", font=("Arial", 12),
            width=120, height=28, fg_color="#6c757d", hover_color="#5a6268",
            command=self.back_callback
        )
        self.btn_back.grid(row=0, column=0, sticky="w", padx=4, pady=(0, 10))

        self.header_frame = ctk.CTkFrame(self, fg_color=("#E5E9F0", "#2E3440"), corner_radius=10)
        self.header_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 2))
        self.header_frame.grid_columnconfigure(1, weight=1)

        self.load_avatar()
        if self.avatar_img:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, image=self.avatar_img, text="")
        else:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, text="🐴", font=("Arial", 18))
        self.avatar_lbl.grid(row=0, column=0, padx=8, pady=6)

        self.title_lbl = ctk.CTkLabel(self.header_frame, text="🔥 Cờ Caro 10x10", font=("Arial", 11, "bold"), text_color="#1f538d")
        self.title_lbl.grid(row=0, column=1, sticky="w", padx=(0, 8))

        self.comment_card = ctk.CTkFrame(self, fg_color=("#ECEFF4", "#242933"), corner_radius=8)
        self.comment_card.grid(row=2, column=0, sticky="ew", padx=4, pady=2)
        self.comment_lbl = ctk.CTkLabel(
            self.comment_card, 
            text="Teio: 'Bàn đấu 10x10 rộng thênh thang đã mở! Trainer cẩn thận nhé! 🚀'",
            font=("Arial", 10, "italic"), wraplength=380, text_color="#2E3440", justify="center"
        )
        self.comment_lbl.pack(padx=8, pady=6)

        self.board_container = ctk.CTkFrame(self, fg_color=("#D8DEE9", "#3B4252"), corner_radius=12)
        self.board_container.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)
        for i in range(self.size):
            self.board_container.grid_rowconfigure(i, weight=1)
            self.board_container.grid_columnconfigure(i, weight=1)

        self.buttons = []
        for r in range(self.size):
            for c in range(self.size):
                idx = r * self.size + c
                btn = ctk.CTkButton(
                    self.board_container, text="", font=("Arial", 15, "bold"),
                    fg_color=("#FFFFFF", "#2E3440"), hover_color=("#E5E9F0", "#4C566A"),
                    text_color="#1f538d", corner_radius=6, width=38, height=38,
                    command=lambda index=idx: self.human_move(index)
                )
                btn.grid(row=r, column=c, padx=2, pady=2, sticky="")
                self.buttons.append(btn)

        self.reset_btn = ctk.CTkButton(
            self, text="🔄 Ván Mới", font=("Arial", 11, "bold"),
            height=34, fg_color="#1f538d", hover_color="#14375e",
            command=self.reset_game
        )
        self.reset_btn.grid(row=4, column=0, sticky="ew", padx=4, pady=(2, 4))

    def load_avatar(self):
        avatar_path = "assets/teio_avatar.png"
        if os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                self.avatar_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(30, 30))
            except Exception: self.avatar_img = None
        else: self.avatar_img = None

    def update_commentary(self, event_type):
        human_comments = ["Teio: 'Nước đi hay đấy Trainer! 🧐'", "Teio: 'Á à! Định bẫy em sao? ✨'", "Teio: 'Tốc độ đi cờ mượt mà quá! 🚀'", "Teio: 'Hừm, Trainer chơi khó thế nhỉ? 🤔'"]
        ai_comments = ["Teio: 'Em vừa chặn đường tiến công rồi! 😎'", "Teio: 'Cú bứt tốc Teio Step! ⚡'", "Teio: 'Bàn cờ này là của em! 🎯'", "Teio: 'Đế vương ra tay là chuẩn xác! 👑'"]
        msg = random.choice(human_comments if event_type == "human_move" else ai_comments)
        self.comment_lbl.configure(text=msg)

    def human_move(self, idx):
        if self.board[idx] == "" and not self.game_over:
            self.board[idx] = self.human
            self.buttons[idx].configure(text=self.human, text_color="#D81B60")
            if self.check_win(self.board, self.human):
                self.end_game("win"); return
            elif "" not in self.board:
                self.end_game("draw"); return
            self.update_commentary("human_move")
            self.after(300, self.ai_move)

    def ai_move(self):
        if self.game_over: return
        best_move = self.find_best_move()
        if best_move is not None:
            self.board[best_move] = self.ai
            self.buttons[best_move].configure(text=self.ai, text_color="#1E88E5")
            if self.check_win(self.board, self.ai):
                self.end_game("lose"); return
            elif "" not in self.board:
                self.end_game("draw"); return
            self.update_commentary("ai_move")

    def find_best_move(self):
        empty_cells = [i for i, cell in enumerate(self.board) if cell == ""]
        if not empty_cells: return None
        for idx in empty_cells:
            self.board[idx] = self.ai
            if self.check_win(self.board, self.ai):
                self.board[idx] = ""; return idx
            self.board[idx] = ""
        for idx in empty_cells:
            self.board[idx] = self.human
            if self.check_win(self.board, self.human):
                self.board[idx] = ""; return idx
            self.board[idx] = ""
        return random.choice(empty_cells)

    def check_win(self, b, mark):
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for r in range(self.size):
            for c in range(self.size):
                if b[r * self.size + c] == mark:
                    for dr, dc in directions:
                        win = True
                        for step in range(1, self.win_streak):
                            nr, nc = r + dr * step, c + dc * step
                            if not (0 <= nr < self.size and 0 <= nc < self.size) or b[nr * self.size + nc] != mark:
                                win = False; break
                        if win: return True
        return False

    def end_game(self, result):
        self.game_over = True
        res_msg = {"win": "Teio: 'Huhu... Trainer giỏi quá! 😭'", "lose": "Teio: 'Hahaha! Thắng rồi! 👑'", "draw": "Teio: 'Hòa nhau rồi! 🤝'"}[result]
        self.comment_lbl.configure(text=res_msg)
        self.show_victory_popup(result, res_msg)

    def show_victory_popup(self, result, end_comment):
        popup = ctk.CTkToplevel(self)
        popup.title("Kết quả")
        popup.geometry("300x200")
        popup.grab_set()
        card = ctk.CTkFrame(popup, corner_radius=12)
        card.pack(fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(card, text="🏁", font=("Arial", 40)).pack(pady=20)
        ctk.CTkLabel(card, text=end_comment, wraplength=250).pack(pady=10)
        ctk.CTkButton(card, text="Đóng", command=popup.destroy).pack(pady=10)

    def reset_game(self):
        self.board = [""] * (self.size * self.size)
        self.game_over = False
        for btn in self.buttons: btn.configure(text="")
        self.comment_lbl.configure(text="Teio: 'Ván mới bắt đầu! Lần này em sẽ không nhường đâu! 🚀'")

