# -*- coding: utf-8 -*-
from .caro_game import CaroGame

