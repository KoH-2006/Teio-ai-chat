# -*- coding: utf-8 -*-

from .chat_view import ChatView
from .game_view import GameView
from .setting_view import SettingView
