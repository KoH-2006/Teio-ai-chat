# -*- coding: utf-8 -*-
from .flappy_teio import FlappyTeio