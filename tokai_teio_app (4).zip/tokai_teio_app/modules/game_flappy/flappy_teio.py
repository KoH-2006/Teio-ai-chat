# -*- coding: utf-8 -*-
import customtkinter as ctk
import tkinter as tk
import os
import time
import random
import math
from PIL import ImageTk, Image

try:
    from .constants import CANVAS_WIDTH, CANVAS_HEIGHT, GRAVITY, JUMP_FORCE, HIGHSCORE_FILE, TOTAL_CARROTS_FILE
    from .assets_loader import AssetsLoader
    from .entities import PipeManager, MamboManager
    from .dialogues import START_QUOTES, GAME_QUOTES, DEAD_QUOTES
except ImportError:
    from constants import CANVAS_WIDTH, CANVAS_HEIGHT, GRAVITY, JUMP_FORCE, HIGHSCORE_FILE, TOTAL_CARROTS_FILE
    from assets_loader import AssetsLoader
    from entities import PipeManager, MamboManager
    from dialogues import START_QUOTES, GAME_QUOTES, DEAD_QUOTES

class FlappyTeio(ctk.CTkFrame):
    def __init__(self, master, back_callback=None, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.back_callback = back_callback
        
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.game_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.game_frame.pack(expand=True, fill="both")
        
        top_bar = ctk.CTkFrame(self.game_frame, fg_color="transparent", height=40)
        top_bar.pack(fill="x", padx=20, pady=(10, 0))
        
        btn_back = ctk.CTkButton(
            top_bar, text="⬅ Quay lại Menu", width=110, height=32,
            fg_color="#6c757d", font=("Arial", 12, "bold"),
            command=self.return_to_menu
        )
        btn_back.pack(side="left")

        self.canvas = tk.Canvas(
            self.game_frame, width=CANVAS_WIDTH, height=CANVAS_HEIGHT,
            highlightthickness=0, bg="#70c5ce"
        )
        self.canvas.pack(pady=10)
        
        self.assets = AssetsLoader()
        self.pipe_mgr = PipeManager()
        self.mambo_mgr = MamboManager()
        
        self.highscores = self.load_highscores()
        self.total_carrots = self.load_total_carrots()
        self.time_cycle = 0.0
        
        self.state = "menu"  # "menu", "playing", "game_over", "shop", "highscore"
        self.equipped_skin = "Mặc định"
        self.unlocked_skins = ["Mặc định"]
        
        self._mountain_tk_cache = {}
        self._current_teio_photo = None
        self._mambo_tk_cache = {}
        
        self.mountain_instances = []
        self._init_giant_mountains()
        
        self.setup_game()
        
        self.is_running = True
        self.focus_set()
        self.bind("<Button-1>", lambda e: self.focus_set())
        
        self.canvas.bind("<Button-1>", self.on_click)
        
        self.top_level = self.winfo_toplevel()
        self.top_level.bind("<space>", self.on_space)
        self.top_level.bind("m", self.on_press_m)
        self.top_level.bind("M", self.on_press_m)
        
        self.update_game()

    def _init_giant_mountains(self):
        if not self.assets.mountain_imgs:
            return

        self.mountain_instances.clear()
        x = -200
        while x < CANVAS_WIDTH + 500:
            img_idx = random.randint(0, len(self.assets.mountain_imgs) - 1)
            pil_img = self.assets.mountain_imgs[img_idx]
            
            w = random.randint(1200, 1500)
            orig_w, orig_h = pil_img.size
            h = int(w * (orig_h / orig_w))
            
            self.mountain_instances.append({
                "x": x, "w": w, "h": h, "img_idx": img_idx
            })
            x += w - random.randint(300, 450)

    def _update_giant_mountains(self):
        if self.state != "playing":
            return
            
        if not self.assets.mountain_imgs:
            return

        speed = 2.0
        for m in self.mountain_instances:
            m["x"] -= speed
            
        while self.mountain_instances and (self.mountain_instances[0]["x"] + self.mountain_instances[0]["w"] < -200):
            self.mountain_instances.pop(0)
            
        if self.mountain_instances:
            last_m = self.mountain_instances[-1]
            right_edge = last_m["x"] + last_m["w"] - random.randint(300, 450)
        else:
            right_edge = -200

        while right_edge < CANVAS_WIDTH + 500:
            img_idx = random.randint(0, len(self.assets.mountain_imgs) - 1)
            pil_img = self.assets.mountain_imgs[img_idx]
            
            w = random.randint(1200, 1500)
            orig_w, orig_h = pil_img.size
            h = int(w * (orig_h / orig_w))
            
            self.mountain_instances.append({
                "x": right_edge, "w": w, "h": h, "img_idx": img_idx
            })
            right_edge += w - random.randint(300, 450)

    def return_to_menu(self):
        self.is_running = False
        try:
            if hasattr(self, 'top_level') and self.top_level.winfo_exists():
                self.top_level.unbind("<space>")
                self.top_level.unbind("m")
                self.top_level.unbind("M")
        except:
            pass
        if self.back_callback:
            self.back_callback()

    def destroy(self):
        self.is_running = False
        try:
            if hasattr(self, 'top_level') and self.top_level.winfo_exists():
                self.top_level.unbind("<space>")
                self.top_level.unbind("m")
                self.top_level.unbind("M")
        except:
            pass
        super().destroy()

    def load_highscores(self):
        scores = []
        if os.path.exists(HIGHSCORE_FILE):
            try:
                with open(HIGHSCORE_FILE, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line.isdigit():
                            scores.append(int(line))
            except:
                pass
        scores.sort(reverse=True)
        return scores[:10]

    def save_highscore(self):
        if self.score > 0:
            self.highscores.append(int(self.score))
        self.highscores.sort(reverse=True)
        self.highscores = self.highscores[:10]
        try:
            os.makedirs("data", exist_ok=True)
            with open(HIGHSCORE_FILE, "w") as f:
                for s in self.highscores:
                    f.write(f"{s}\n")
        except Exception as e:
            print(f"Lỗi lưu danh sách kỷ lục: {e}")

    def reset_highscores(self):
        self.highscores = []
        try:
            os.makedirs("data", exist_ok=True)
            with open(HIGHSCORE_FILE, "w") as f:
                f.write("")
        except Exception as e:
            print(f"Lỗi reset kỷ lục: {e}")

    def load_total_carrots(self):
        if os.path.exists(TOTAL_CARROTS_FILE):
            try:
                with open(TOTAL_CARROTS_FILE, "r") as f:
                    return int(f.read().strip() or 0)
            except:
                return 0
        return 0

    def save_total_carrots(self):
        try:
            os.makedirs("data", exist_ok=True)
            with open(TOTAL_CARROTS_FILE, "w") as f:
                f.write(str(int(self.total_carrots)))
        except Exception as e:
            print(f"Lỗi lưu tổng số cà rốt: {e}")

    def setup_game(self):
        self.player_y = CANVAS_HEIGHT // 2
        self.player_vel = 0
        self.pipe_mgr.reset()
        self.mambo_mgr.reset()
        self.score = 0
        self.invincible = False
        self.invincible_end = 0
        self.comment = random.choice(START_QUOTES)
        self._current_teio_photo = None

    def on_space(self, event):
        if not self.is_running or not self.winfo_exists():
            return
        
        if self.state == "menu":
            self.state = "playing"
            self.setup_game()
        elif self.state == "playing":
            self.player_vel = JUMP_FORCE
            self.comment = random.choice(GAME_QUOTES)
        elif self.state == "game_over":
            self.state = "playing"
            self.setup_game()

    def on_press_m(self, event):
        if self.state == "game_over":
            self.state = "menu"

    def on_click(self, event):
        x, y = event.x, event.y
        if self.state == "menu":
            if CANVAS_WIDTH//2 - 140 <= x <= CANVAS_WIDTH//2 + 140:
                if 220 <= y <= 285:
                    self.state = "playing"
                    self.setup_game()
                elif 300 <= y <= 365:
                    self.state = "shop"
                elif 380 <= y <= 445:
                    self.state = "highscore"
        elif self.state == "shop":
            if 20 <= x <= 120 and 20 <= y <= 55:
                self.state = "menu"
            elif CANVAS_WIDTH//2 - 100 <= x <= CANVAS_WIDTH//2 + 100:
                if 220 <= y <= 260:
                    self.equipped_skin = "Mặc định"
                elif 280 <= y <= 320:
                    max_score = self.highscores[0] if self.highscores else 0
                    if "Tốc độ ánh sáng" in self.unlocked_skins:
                        self.equipped_skin = "Tốc độ ánh sáng"
                    elif max_score >= 10:
                        self.unlocked_skins.append("Tốc độ ánh sáng")
                        self.equipped_skin = "Tốc độ ánh sáng"
        elif self.state == "highscore":
            if 20 <= x <= 120 and 20 <= y <= 55:
                self.state = "menu"
            elif CANVAS_WIDTH//2 - 90 <= x <= CANVAS_WIDTH//2 + 90 and 520 <= y <= 565:
                self.reset_highscores()
        elif self.state == "game_over":
            px = CANVAS_WIDTH // 2
            py = CANVAS_HEIGHT // 2
            
            if px - 135 <= x <= px - 10 and py + 15 <= y <= py + 75:
                self.state = "menu"
            elif px + 10 <= x <= px + 135 and py + 15 <= y <= py + 75:
                self.state = "playing"
                self.setup_game()
        else:
            self.on_space(event)

    def _interpolate_color(self, color1_hex, color2_hex, factor):
        r1, g1, b1 = int(color1_hex[1:3], 16), int(color1_hex[3:5], 16), int(color1_hex[5:7], 16)
        r2, g2, b2 = int(color2_hex[1:3], 16), int(color2_hex[3:5], 16), int(color2_hex[5:7], 16)
        r = int(r1 + (r2 - r1) * factor)
        g = int(g1 + (g2 - g1) * factor)
        b = int(b1 + (b2 - b1) * factor)
        return f"#{r:02x}{g:02x}{b:02x}"

    def get_sky_color(self):
        t = (math.sin(self.time_cycle) + 1) / 2.0
        day_color = "#70c5ce"
        sunset_color = "#e27d60"
        night_color = "#1a1c2e"
        if t > 0.6:
            return self._interpolate_color(sunset_color, day_color, (t - 0.6) / 0.4)
        elif t > 0.2:
            return self._interpolate_color(night_color, sunset_color, (t - 0.2) / 0.4)
        else:
            return night_color

    def update_game(self):
        if not self.is_running or not self.winfo_exists():
            return

        if self.state in ["menu", "playing"]:
            self.time_cycle += 0.000334
            
        self._update_giant_mountains()

        if self.state == "playing":
            self.player_vel += GRAVITY
            self.player_y += self.player_vel

            if self.invincible and time.time() > self.invincible_end:
                self.invincible = False
                self.comment = "Hết hiệu ứng mật ong rồi! Cẩn thận nhé Trainer! ⚠️"

            if not self.pipe_mgr.pipes or self.pipe_mgr.pipes[-1]["x"] < CANVAS_WIDTH - 220:
                self.pipe_mgr.spawn()

            px, py = 100, self.player_y
            
            self.pipe_mgr.update()
            for p in self.pipe_mgr.pipes:
                if not self.invincible:
                    # Nới rộng một chút cho phù hợp Teio phóng to
                    if p["x"] < px + 22 and p["x"] + p["width"] > px - 22:
                        if py - 22 < p["gap_bottom"] or py + 22 > p["gap_top"]:
                            self.trigger_game_over()

                if p["item"] and not p["item"]["collected"]:
                    it = p["item"]
                    if abs(it["x"] - px) < 28 and abs(it["y"] - py) < 28:
                        it["collected"] = True
                        if it["type"] == "carrot":
                            self.score += 1
                            self.total_carrots += 1
                            self.save_total_carrots()
                            self.comment = random.choice([
                                "Ngon tuyệt! Cà rốt tiếp năng lượng cho Teio! 🥕",
                                "Ăn cà rốt để tăng điểm số nào! ✨",
                                "Húp trọn cà rốt, điểm số tăng vèo vèo! 🥕"
                            ])
                        elif it["type"] == "honey":
                            self.invincible = True
                            self.invincible_end = time.time() + 5
                            self.comment = "Oa! Mật ong siêu cấp! Teio bất tử rồi Trainer ơi! 🍯"

            self.mambo_mgr.update(py)
            for m in self.mambo_mgr.mambos[:]:
                if abs(m["x"] - px) < 32 and abs(m["y"] - py) < 32:
                    if self.invincible:
                        m["falling"] = True
                        self.comment = "Teio bất tử húc bay Mambo rồi! Quá đỉnh Trainer ơi! 💥"
                    else:
                        self.trigger_game_over()

                if m.get("falling"):
                    m["y"] += 6.0
                    m["x"] -= 2.0
                    if m["y"] > CANVAS_HEIGHT + 50:
                        self.mambo_mgr.mambos.remove(m)

            if self.player_y < 0 or self.player_y > CANVAS_HEIGHT - 40:
                self.trigger_game_over()

        self.render()
        if self.is_running and self.winfo_exists():
            try:
                self.after(16, self.update_game)
            except Exception:
                pass

    def trigger_game_over(self):
        self.state = "game_over"
        self.save_highscore()
        self.comment = random.choice(DEAD_QUOTES)

    def draw_landscape(self):
        sky_bg = self.get_sky_color()
        self.canvas.configure(bg=sky_bg)
        self.canvas.create_rectangle(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT, fill=sky_bg, outline="")
        
        sun_moon_x = int((self.time_cycle * 50) % (CANVAS_WIDTH + 100)) - 50
        is_night = math.sin(self.time_cycle) < 0
        if not is_night:
            self.canvas.create_oval(sun_moon_x, 40, sun_moon_x + 50, 90, fill="#FFFACD", outline="#FFE4B5", width=2)
        else:
            self.canvas.create_oval(sun_moon_x, 45, sun_moon_x + 45, 90, fill="#F0E68C", outline="#EEE8AA", width=2)

        cloud_color = "#FFFFFF" if not is_night else "#4A5568"
        cloud_time = time.time() if self.state != "game_over" else 0
        cloud_shift = (cloud_time * 20) % (CANVAS_WIDTH + 160)
        for offset in [-160, 0, CANVAS_WIDTH]:
            cx = offset + (CANVAS_WIDTH - cloud_shift)
            cy = 75
            self.canvas.create_oval(cx, cy, cx + 50, cy + 25, fill=cloud_color, outline="")
            self.canvas.create_oval(cx + 20, cy - 12, cx + 70, cy + 22, fill=cloud_color, outline="")
            self.canvas.create_oval(cx + 40, cy, cx + 90, cy + 25, fill=cloud_color, outline="")

        base_y = CANVAS_HEIGHT - 35
        for m in self.mountain_instances:
            mx, mw, mh, img_idx = m["x"], m["w"], m["h"] + 60, m["img_idx"]
            my = base_y - mh + 80
            
            cache_key = (img_idx, mw, mh)
            if cache_key not in self._mountain_tk_cache:
                pil_img = self.assets.mountain_imgs[img_idx].resize((mw, mh), Image.Resampling.LANCZOS)
                self._mountain_tk_cache[cache_key] = ImageTk.PhotoImage(pil_img)
                
            self.canvas.create_image(mx, my, image=self._mountain_tk_cache[cache_key], anchor="nw")

        ground_h = 40
        ground_color = "#DDD896" if not is_night else "#5A5438"
        grass_color = "#5cAD4A" if not is_night else "#2D5A27"
        self.canvas.create_rectangle(0, CANVAS_HEIGHT - ground_h, CANVAS_WIDTH, CANVAS_HEIGHT, fill=ground_color, outline="#C8B878", width=2)
        self.canvas.create_rectangle(0, CANVAS_HEIGHT - ground_h, CANVAS_WIDTH, CANVAS_HEIGHT - ground_h + 8, fill=grass_color, outline="")

    def render(self):
        if not self.winfo_exists():
            return
        try:
            self.canvas.delete("all")
            self.draw_landscape()

            # Hiển thị tổng số cà rốt tích lũy ở góc trên bên phải
            self.canvas.create_text(CANVAS_WIDTH - 15, 20, text=f"🥕 Tích lũy: {self.total_carrots}", anchor="ne", fill="#FFD700", font=("Arial", 12, "bold"))

            if self.state == "menu":
                self.canvas.create_text(CANVAS_WIDTH//2, 110, text="FLAPPY TEIO", anchor="center", fill="#FFD700", font=("Arial", 28, "bold"))
                self.canvas.create_text(CANVAS_WIDTH//2, 150, text="✨ Chinh phục bầu trời cùng Tokai Teio ✨", anchor="center", fill="white", font=("Arial", 13, "italic"))
                
                if self.assets.btn_start_img:
                    self.canvas.create_image(CANVAS_WIDTH//2, 250, image=self.assets.btn_start_img)
                else:
                    self.canvas.create_rectangle(CANVAS_WIDTH//2 - 120, 220, CANVAS_WIDTH//2 + 120, 280, fill="#4CAF50", outline="white", width=2)
                    self.canvas.create_text(CANVAS_WIDTH//2, 250, text="▶ BẮT ĐẦU", anchor="center", fill="white", font=("Arial", 16, "bold"))

                if self.assets.btn_shop_img:
                    self.canvas.create_image(CANVAS_WIDTH//2, 332, image=self.assets.btn_shop_img)
                else:
                    self.canvas.create_rectangle(CANVAS_WIDTH//2 - 120, 295, CANVAS_WIDTH//2 + 120, 355, fill="#FF9800", outline="white", width=2)
                    self.canvas.create_text(CANVAS_WIDTH//2, 325, text="🛍️ CỬA HÀNG SKIN", anchor="center", fill="white", font=("Arial", 16, "bold"))

                if self.assets.btn_highscore_img:
                    self.canvas.create_image(CANVAS_WIDTH//2, 412, image=self.assets.btn_highscore_img)
                else:
                    self.canvas.create_rectangle(CANVAS_WIDTH//2 - 120, 370, CANVAS_WIDTH//2 + 120, 430, fill="#2196F3", outline="white", width=2)
                    top_score = self.highscores[0] if self.highscores else 0
                    self.canvas.create_text(CANVAS_WIDTH//2, 400, text=f"🏆 KỶ LỤC: {int(top_score)}", anchor="center", fill="white", font=("Arial", 15, "bold"))
                return

            if self.state == "shop":
                self.canvas.create_rectangle(20, 20, 120, 55, fill="#6c757d", outline="white", width=2)
                self.canvas.create_text(70, 37, text="⬅ Quay lại", anchor="center", fill="white", font=("Arial", 12, "bold"))
                
                self.canvas.create_text(CANVAS_WIDTH//2, 100, text="CỬA HÀNG SKIN TEIO", anchor="center", fill="#FFD700", font=("Arial", 20, "bold"))
                
                self.canvas.create_rectangle(CANVAS_WIDTH//2 - 100, 220, CANVAS_WIDTH//2 + 100, 260, fill="#333333", outline="#FFD700" if self.equipped_skin=="Mặc định" else "white", width=2)
                self.canvas.create_text(CANVAS_WIDTH//2, 240, text=f"Mặc định {'(Đang chọn)' if self.equipped_skin=='Mặc định' else ''}", anchor="center", fill="white", font=("Arial", 12, "bold"))

                max_score = self.highscores[0] if self.highscores else 0
                is_unlocked = "Tốc độ ánh sáng" in self.unlocked_skins or max_score >= 10
                status_text = "Đang chọn" if self.equipped_skin=="Tốc độ ánh sáng" else ("Đã mở khóa" if is_unlocked else "Yêu cầu: 10 Điểm")
                box_color = "#2E7D32" if is_unlocked else "#555555"
                self.canvas.create_rectangle(CANVAS_WIDTH//2 - 100, 280, CANVAS_WIDTH//2 + 100, 320, fill=box_color, outline="#FFD700" if self.equipped_skin=="Tốc độ ánh sáng" else "white", width=2)
                self.canvas.create_text(CANVAS_WIDTH//2, 300, text=f"Tốc độ ánh sáng ({status_text})", anchor="center", fill="white", font=("Arial", 11, "bold"))
                return

            if self.state == "highscore":
                self.canvas.create_rectangle(20, 20, 120, 55, fill="#6c757d", outline="white", width=2)
                self.canvas.create_text(70, 37, text="⬅ Quay lại", anchor="center", fill="white", font=("Arial", 12, "bold"))
                
                self.canvas.create_text(CANVAS_WIDTH//2, 75, text="🏆 TOP 10 KỶ LỤC 🏆", anchor="center", fill="#FFD700", font=("Arial", 20, "bold"))
                
                # Hiển thị danh sách Top 10
                start_y = 115
                row_h = 36
                if not self.highscores:
                    self.canvas.create_text(CANVAS_WIDTH//2, 250, text="Chưa có kỷ lục nào được ghi nhận!", anchor="center", fill="white", font=("Arial", 13, "italic"))
                else:
                    for idx, s in enumerate(self.highscores[:10]):
                        y_pos = start_y + idx * row_h
                        color = "#FFD700" if idx == 0 else ("#C0C0C0" if idx == 1 else ("#CD7F32" if idx == 2 else "white"))
                        rank_str = f"Top {idx+1}:"
                        self.canvas.create_text(CANVAS_WIDTH//2 - 70, y_pos, text=rank_str, anchor="w", fill=color, font=("Arial", 13, "bold"))
                        self.canvas.create_text(CANVAS_WIDTH//2 + 70, y_pos, text=f"{int(s)} điểm", anchor="e", fill=color, font=("Arial", 13, "bold"))

                # Nút Reset kỷ lục
                self.canvas.create_rectangle(CANVAS_WIDTH//2 - 90, 520, CANVAS_WIDTH//2 + 90, 565, fill="#D9534F", outline="white", width=2)
                self.canvas.create_text(CANVAS_WIDTH//2, 542, text="🔄 Reset Kỷ Lục", anchor="center", fill="white", font=("Arial", 12, "bold"))
                return

            # --- TRONG TRẬN ĐẤU (PLAYING / GAME OVER) ---
            for p in self.pipe_mgr.pipes:
                x, w, gb, gt = p["x"], 90, p["gap_bottom"], p["gap_top"]
                
                # Ống trên
                self.canvas.create_rectangle(x, 0, x + w, gb - 24, fill="#73bf2e", outline="#3b5a17", width=2)
                self.canvas.create_rectangle(x + 4, 0, x + 16, gb - 24, fill="#9fe345", outline="")
                self.canvas.create_rectangle(x + w - 16, 0, x + w - 4, gb - 24, fill="#558022", outline="")
                cap_h = 24
                cap_w_extra = 6
                self.canvas.create_rectangle(x - cap_w_extra, gb - cap_h, x + w + cap_w_extra, gb, fill="#73bf2e", outline="#3b5a17", width=2)
                self.canvas.create_rectangle(x - cap_w_extra + 4, gb - cap_h + 3, x + w + cap_w_extra - 4, gb - cap_h + 8, fill="#9fe345", outline="")

                # Ống dưới
                self.canvas.create_rectangle(x - cap_w_extra, gt, x + w + cap_w_extra, gt + cap_h, fill="#73bf2e", outline="#3b5a17", width=2)
                self.canvas.create_rectangle(x - cap_w_extra + 4, gt + 3, x + w + cap_w_extra - 4, gt + 8, fill="#9fe345", outline="")
                self.canvas.create_rectangle(x, gt + cap_h, x + w, CANVAS_HEIGHT - 40, fill="#73bf2e", outline="#3b5a17", width=2)
                self.canvas.create_rectangle(x + 4, gt + cap_h, x + 16, CANVAS_HEIGHT - 40, fill="#9fe345", outline="")
                self.canvas.create_rectangle(x + w - 16, gt + cap_h, x + w - 4, CANVAS_HEIGHT - 40, fill="#558022", outline="")

                if p["item"] and not p["item"]["collected"]:
                    it = p["item"]
                    ix, iy, itype = it["x"], it["y"], it["type"]
                    img = self.assets.carrot_img if itype == "carrot" else self.assets.honey_img
                    if img:
                        self.canvas.create_image(ix, iy, image=img)
                    else:
                        color = "orange" if itype == "carrot" else "gold"
                        self.canvas.create_oval(ix-12, iy-12, ix+12, iy+12, fill=color)

            for m in self.mambo_mgr.mambos:
                mx, my = m["x"], m["y"]
                if self.assets.mambo_pil_img:
                    if m.get("falling"):
                        cache_key = ("mambo_falling",)
                        if cache_key not in self._mambo_tk_cache:
                            rotated_pil = self.assets.mambo_pil_img.rotate(90, resample=Image.BILINEAR, expand=True)
                            self._mambo_tk_cache[cache_key] = ImageTk.PhotoImage(rotated_pil)
                        self.canvas.create_image(mx, my, image=self._mambo_tk_cache[cache_key])
                    else:
                        cache_key = ("mambo_normal",)
                        if cache_key not in self._mambo_tk_cache:
                            self._mambo_tk_cache[cache_key] = ImageTk.PhotoImage(self.assets.mambo_pil_img)
                        self.canvas.create_image(mx, my, image=self._mambo_tk_cache[cache_key])
                else:
                    self.canvas.create_oval(mx-15, my-15, mx+15, my+15, fill="purple")

            if not (self.invincible and (int(time.time() * 10) % 2 == 0)):
                if self.assets.teio_pil_img:
                    angle = max(-30, min(35, -self.player_vel * 4))
                    rotated_pil = self.assets.teio_pil_img.rotate(angle, resample=Image.BILINEAR, expand=True)
                    self._current_teio_photo = ImageTk.PhotoImage(rotated_pil)
                    self.canvas.create_image(100, self.player_y, image=self._current_teio_photo)
                else:
                    self.canvas.create_oval(85, self.player_y-18, 115, self.player_y+18, fill="pink")
                
                if self.invincible:
                    self.canvas.create_oval(75, self.player_y-25, 125, self.player_y+25, outline="gold", width=3)

            top_score = self.highscores[0] if self.highscores else 0
            self.canvas.create_text(15, 20, text=f"Score: {int(self.score)} | High: {int(top_score)}", anchor="nw", fill="white", font=("Arial", 14, "bold"))
            self.canvas.create_text(CANVAS_WIDTH // 2, 50, text=self.comment, anchor="center", fill="yellow", font=("Arial", 12, "italic"))

            if self.state == "game_over":
                if self.assets.gameover_panel_img:
                    px = CANVAS_WIDTH // 2
                    py = CANVAS_HEIGHT // 2
                    
                    self.canvas.create_image(px, py, image=self.assets.gameover_panel_img)
                    
                    self.canvas.create_text(px + 55, py - 35, text=f"Điểm: {int(self.score)}", anchor="center", fill="#FFFFFF", font=("Arial", 15, "bold"))
                    self.canvas.create_text(px + 55, py - 10, text=f"Kỷ lục: {int(top_score)}", anchor="center", fill="#FFD700", font=("Arial", 13, "bold"))
                else:
                    self.canvas.create_rectangle(CANVAS_WIDTH // 2 - 170, CANVAS_HEIGHT // 2 - 90, CANVAS_WIDTH // 2 + 170, CANVAS_HEIGHT // 2 + 90, fill="#2c3e50", outline="gold", width=3)
                    self.canvas.create_text(CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2 - 40, text="GAME OVER!", anchor="center", fill="red", font=("Arial", 22, "bold"))
                    self.canvas.create_text(CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2 + 20, text=f"Điểm: {int(self.score)} | Kỷ lục: {int(top_score)}", anchor="center", fill="white", font=("Arial", 14, "bold"))
        except Exception as e:
            print(f"Lỗi render: {e}")