# -*- coding: utf-8 -*-
import os
import tkinter as tk
from PIL import Image, ImageTk

class AssetsLoader:
    def __init__(self):
        self.bg_img = None
        self.mountain_imgs = []
        self.carrot_img = None
        self.honey_img = None
        self.mambo_pil_img = None
        self.teio_pil_img = None
        
        self.btn_start_img = None
        self.btn_shop_img = None
        self.btn_highscore_img = None
        self.gameover_panel_img = None
        
        self.load_all()

    def load_all(self):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        possible_paths = [
            os.path.join(current_dir, "..", "assets", "flappy"),
            os.path.join(current_dir, "assets", "flappy"),
            os.path.join(os.getcwd(), "assets", "flappy"),
            os.path.join(os.getcwd(), "game_flappy", "assets", "flappy")
        ]
        
        path = None
        for p in possible_paths:
            if os.path.exists(p):
                path = p
                break
        
        if not path:
            return

        self.bg_img = self._load_tk_img(os.path.join(path, "nen.png"))
        
        self.mountain_imgs = []
        i = 1
        while True:
            loaded = False
            for ext in [".jpg", ".png", ".jpeg"]:
                m_path = os.path.join(path, f"m{i}{ext}")
                if os.path.exists(m_path):
                    try:
                        pil_img = Image.open(m_path).convert("RGBA")
                        self.mountain_imgs.append(pil_img)
                        loaded = True
                        break
                    except Exception as e:
                        print(f"Lỗi load ảnh núi m{i}: {e}")
            if not loaded:
                break
            i += 1

        self.btn_start_img = self._load_proportional_btn(path, ["btn_start.png", "bd.png", "bd.jpg"], target_width=280)
        self.btn_shop_img = self._load_proportional_btn(path, ["btn_shop.png", "skin.png", "skin.jpg"], target_width=280)
        self.btn_highscore_img = self._load_proportional_btn(path, ["btn_highscore.png", "kl.png", "kl.jpg"], target_width=280)
        self.gameover_panel_img = self._load_proportional_btn(path, ["end.jpg", "end.png", "gameover_panel.png", "image_1239e3.jpg"], target_width=330)

        # 1. Teio: Phóng to hơn chút (target_width = 60)
        teio_path = os.path.join(path, "teio_fly.png")
        if os.path.exists(teio_path):
            try:
                pil_img = Image.open(teio_path).convert("RGBA")
                orig_w, orig_h = pil_img.size
                target_width = 60  
                target_height = int(target_width * (orig_h / orig_w))
                self.teio_pil_img = pil_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
            except Exception as e:
                print(f"Lỗi load PIL ảnh Teio: {e}")

        # 2. Cà rốt & Mật ong
        self.carrot_img = self._load_proportional_tk(os.path.join(path, "carrot.png"), target_width=28)
        self.honey_img = self._load_proportional_tk(os.path.join(path, "honey.png"), target_width=28)

        # 3. Mambo: Phóng to hơn chút (target_width = 52)
        mambo_path = os.path.join(path, "mambo.png")
        if os.path.exists(mambo_path):
            try:
                pil_img = Image.open(mambo_path).convert("RGBA")
                orig_w, orig_h = pil_img.size
                target_width = 52
                target_height = int(target_width * (orig_h / orig_w))
                self.mambo_pil_img = pil_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
            except Exception as e:
                print(f"Lỗi load PIL ảnh Mambo: {e}")

    def _load_proportional_tk(self, filepath, target_width=28):
        if os.path.exists(filepath):
            try:
                pil_img = Image.open(filepath).convert("RGBA")
                orig_w, orig_h = pil_img.size
                if orig_w > 0:
                    target_height = int(target_width * (orig_h / orig_w))
                    pil_img = pil_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                return ImageTk.PhotoImage(pil_img)
            except Exception as e:
                print(f"Lỗi load ảnh {filepath}: {e}")
        return None

    def _load_proportional_btn(self, dir_path, filenames, target_width=280):
        for fname in filenames:
            full_p = os.path.join(dir_path, fname)
            if os.path.exists(full_p):
                try:
                    pil_img = Image.open(full_p)
                    
                    if "end" in fname.lower() or "gameover" in fname.lower():
                        gray_img = pil_img.convert("L")
                        bbox = gray_img.point(lambda p: 255 if p > 30 else 0).getbbox()
                        if bbox:
                            pil_img = pil_img.crop(bbox)

                    orig_w, orig_h = pil_img.size
                    target_height = int(target_width * (orig_h / orig_w))
                    pil_img = pil_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                    return ImageTk.PhotoImage(pil_img)
                except Exception as e:
                    print(f"Lỗi resize ảnh {fname}: {e}")
        return None

    def _load_tk_img(self, filepath):
        if os.path.exists(filepath):
            try:
                return tk.PhotoImage(file=filepath)
            except Exception as e:
                print(f"Lỗi load ảnh {filepath}: {e}")
        return None