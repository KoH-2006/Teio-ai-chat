# -*- coding: utf-8 -*-
import random
from .constants import CANVAS_WIDTH, CANVAS_HEIGHT, PIPE_SPEED, MAMBO_SPEED

class PipeManager:
    def __init__(self):
        self.pipes = []
        self.counter = 0

    def reset(self):
        self.pipes.clear()
        self.counter = 0

    def spawn(self):
        self.counter += 1
        gap = 160
        pipe_width = 70
        gap_center = random.randint(180, 420)
        gap_bottom = gap_center - gap // 2
        gap_top = gap_center + gap // 2
        
        # Giảm tần suất xuất hiện item, mật ong cực kỳ hiếm, chủ yếu là cà rốt
        item = None
        if random.random() < 0.3:  # Giảm tỉ lệ có item trong ống
            itype = "carrot" if random.random() < 0.85 else "honey"
            item = {
                "type": itype,
                "x": CANVAS_WIDTH + pipe_width // 2,
                "y": random.randint(gap_bottom + 25, gap_top - 25),
                "collected": False
            }

        self.pipes.append({
            "name": f"pipe({self.counter})",
            "x": CANVAS_WIDTH,
            "width": pipe_width,
            "gap_bottom": gap_bottom,
            "gap_top": gap_top,
            "passed": False,
            "item": item
        })

    def update(self):
        for p in self.pipes[:]:
            p["x"] -= PIPE_SPEED
            if p["item"]:
                p["item"]["x"] -= PIPE_SPEED
            if p["x"] < -80:
                self.pipes.remove(p)


class MamboManager:
    def __init__(self):
        self.mambos = []
        self.spawn_timer = 0

    def reset(self):
        self.mambos.clear()
        self.spawn_timer = 0

    def update(self, player_y):
        self.spawn_timer += 1
        # Tăng khoảng thời gian spawn để giảm tần suất xuất hiện Mambo đáng kể
        if self.spawn_timer > random.randint(180, 250):
            self.spawn_timer = 0
            self.mambos.append({
                "x": CANVAS_WIDTH + 50,
                "y": random.randint(80, CANVAS_HEIGHT - 80),
                "speed": MAMBO_SPEED + random.uniform(0, 0.8)
            })

        for m in self.mambos[:]:
            m["x"] -= m["speed"]
            if m["y"] < player_y:
                m["y"] += 0.5
            elif m["y"] > player_y:
                m["y"] -= 0.5

            if m["x"] < -50:
                self.mambos.remove(m)