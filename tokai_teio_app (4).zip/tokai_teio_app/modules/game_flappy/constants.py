# -*- coding: utf-8 -*-

CANVAS_WIDTH = 400
CANVAS_HEIGHT = 600
GRAVITY = 0.4
JUMP_FORCE = -7.5
PIPE_SPEED = 3.5  
MAMBO_SPEED = 4.0  
HIGHSCORE_FILE = "data/flappy_highscores.txt"
TOTAL_CARROTS_FILE = "data/flappy_total_carrots.txt"