# 🐴 Tokai Teio AI Assistant

Chào mừng Trainer đến với trợ lý ảo **Tokai Teio**! Đây là một ứng dụng AI nhập vai nhân vật Tokai Teio từ *Uma Musume Pretty Derby*, kết hợp giữa công nghệ Local LLM (AI chạy cục bộ) và giao diện hiện đại.

![Version](https://img.shields.io/badge/Version-1.0-blue) 
![Python](https://img.shields.io/badge/Python-3.10+-green) 
![AI](https://img.shields.io/badge/AI-Ollama-orange)

---

## ✨ Tính năng nổi bật

### 💬 Trò chuyện nhập vai (Character Chat)
- **Nhập vai tuyệt đối:** Teio trò chuyện với tính cách nhí nhảnh, năng động, luôn tự xưng là "em" và gọi bạn là "Trainer".
- **Trí nhớ dài hạn:** Tự động lưu lịch sử trò chuyện và thông tin cá nhân của Trainer vào file JSON.
- **Riêng tư 100%:** Toàn bộ dữ liệu và quá trình xử lý AI diễn ra trên máy tính của bạn, không gửi lên đám mây.

### 🎮 Giải trí cùng Teio (Caro Game)
- **Cờ Caro 10x10:** Thử thách trí tuệ với Teio trên bàn cờ rộng.
- **Bình luận viên Teio:** Teio sẽ liên tục đưa ra những lời bình luận hóm hỉnh, trêu chọc hoặc cổ vũ dựa trên từng nước đi của Trainer.

### ⚙️ Tùy chỉnh hệ thống (Settings)
- **Thay đổi Model AI:** Dễ dàng chuyển đổi giữa các model của Ollama (ví dụ: `qwen2.5`, `llama3`, `phi3`).
- **Thiết lập xưng hô:** Tùy chỉnh cách Teio gọi bạn và cách Teio tự xưng.
- **Quản lý ký ức:** Cập nhật thông tin cá nhân để Teio hiểu bạn hơn hoặc xóa ký ức ngắn hạn để bắt đầu lại.

---

## 🛠 Yêu cầu hệ thống

Để ứng dụng chạy mượt mà, máy tính của bạn cần:
1. **Python 3.10 trở lên** (Khi cài đặt hãy tích vào ô **"Add Python to PATH"**).
2. **Ollama** (Phần mềm chạy AI cục bộ). Tải tại: [ollama.com](https://ollama.com/).
3. **Model AI:** Mặc định sử dụng `qwen2.5:1.5b` (Nhẹ, nhanh và thông minh).

---

## 🚀 Hướng dẫn cài đặt chi tiết

### Bước 1: Cài đặt "Bộ não" AI (Ollama)
1. Tải và cài đặt Ollama từ [ollama.com](https://ollama.com/).
2. Mở **Command Prompt (CMD)** và chạy lệnh sau để tải model AI về máy:
   ```bash
   ollama run qwen2.5:1.5b
