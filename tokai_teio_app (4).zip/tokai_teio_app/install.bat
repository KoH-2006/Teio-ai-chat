@echo off
title Tokai Teio AI Assistant - Installer
color 0B
chcp 65001 >nul

echo ======================================================
echo    🐴 TOKAI TEIO AI - CÀI ĐẶT TỰ ĐỘNG 🚀
echo ======================================================
echo.

:: 1. KIỂM TRA PYTHON
echo [+] Đang kiểm tra Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] LỖI: Máy bạn chưa cài đặt Python!
    echo ------------------------------------------------------
    echo Vui lòng tải Python tại: https://www.python.org/
    echo Lưu ý: Khi cài hãy tích vào ô "Add Python to PATH".
    echo ------------------------------------------------------
    pause
    exit
)
echo [OK] Đã tìm thấy Python.

:: 2. CẬP NHẬT PIP
echo.
echo [+] Đang cập nhật trình quản lý thư viện (pip)...
python -m pip install --upgrade pip
if %errorlevel% equ 0 (echo [OK] Cập nhật pip thành công.) else (echo [!] Không thể cập nhật pip, bỏ qua...)

:: 3. CÀI ĐẶT THƯ VIỆN
echo.
echo [+] Đang cài đặt các thư viện cần thiết...
echo ------------------------------------------------------
python -m pip install customtkinter pillow ollama
if %errorlevel% equ 0 (
    echo.
    echo [OK] Đã cài đặt thành công tất cả thư viện! ✅
) else (
    echo.
    echo [!] CÓ LỖI XẢY RA khi cài đặt thư viện. ❌
    echo Hãy thử chạy lại file này bằng quyền Administrator.
    pause
    exit
)

:: 4. HƯỚNG DẪN OLLAMA
echo.
echo ======================================================
echo    ⚠️ BƯỚC CUỐI CÙNG QUAN TRỌNG ⚠️
echo ======================================================
echo 1. Cài đặt Ollama tại: https://ollama.com/
echo 2. Mở CMD và chạy lệnh: ollama run qwen2.5:1.5b
echo 3. Sau đó quay lại đây và chạy app bằng file: tokai_teio_app.py
echo ======================================================
echo.
echo Cài đặt hoàn tất! Chúc Trainer vui vẻ cùng Teio! ✨
echo.
pause
