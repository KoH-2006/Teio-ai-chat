﻿# -*- coding: utf-8 -*-
import os
import json
import subprocess  # <--- Thêm thư viện này để chạy lệnh hệ thống
import threading   # <--- Thêm để chạy kiểm tra Ollama mà không làm treo giao diện
import customtkinter as ctk
from PIL import Image
import ollama       # <--- Import ollama để kiểm tra trạng thái

from modules.chat_view import ChatView
from modules.game_view import GameView
from modules.setting_view import SettingView

ctk.set_appearance_mode("Light")
ctk.set_default_color_theme("blue")

class TokaiTeioApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Tokai Teio AI Assistant")
        self.geometry("420x720") 
        self.minsize(420, 600)

        self.init_system_files()
        
        # --- Tự động kiểm tra và bật Ollama khi khởi động app ---
        # Chạy trong một thread riêng để tránh làm đơ GUI khi chờ server phản hồi
        threading.Thread(target=self.ensure_ollama_running, daemon=True).start()

        # ================= CẤU TRÚC 3 CỘT (LỀ TRÁI - APP DỌC - LỀ PHẢI) =================
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)  
        self.grid_columnconfigure(1, weight=0)  
        self.grid_columnconfigure(2, weight=1)  

        self.left_margin = ctk.CTkFrame(self, fg_color=("#F0F2F5", "#141414"), corner_radius=0)
        self.left_margin.grid(row=0, column=0, sticky="nsew")

        self.app_container = ctk.CTkFrame(self, width=420, fg_color="transparent")
        self.app_container.grid(row=0, column=1, sticky="ns", padx=0, pady=0)
        self.app_container.grid_propagate(False)  

        self.app_container.grid_rowconfigure(0, weight=1)
        self.app_container.grid_rowconfigure(1, weight=0)
        self.app_container.grid_columnconfigure(0, weight=1)

        self.content_frame = ctk.CTkFrame(self.app_container, fg_color="transparent")
        self.content_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=(10, 5))
        self.content_frame.grid_rowconfigure(0, weight=1)
        self.content_frame.grid_columnconfigure(0, weight=1)

        self.nav_bar = ctk.CTkFrame(self.app_container, height=60, fg_color=("#EAEAEA", "#242424"), corner_radius=15)
        self.nav_bar.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        self.nav_bar.grid_columnconfigure((0, 1, 2), weight=1)

        self.btn_chat = ctk.CTkButton(
            self.nav_bar, text="💬 Chat", font=("Arial", 13, "bold"),
            height=42, fg_color="#1f538d", hover_color="#14375e",
            command=self.show_chat_view
        )
        self.btn_chat.grid(row=0, column=0, padx=5, pady=8, sticky="ew")

        self.btn_game = ctk.CTkButton(
            self.nav_bar, text="🎮 Games", font=("Arial", 13, "bold"),
            height=42, fg_color="transparent", text_color=("#000000", "#FFFFFF"),
            hover_color=("#D5D5D5", "#383838"),
            command=self.show_game_view
        )
        self.btn_game.grid(row=0, column=1, padx=5, pady=8, sticky="ew")

        self.btn_setting = ctk.CTkButton(
            self.nav_bar, text="⚙️ Setting", font=("Arial", 13, "bold"),
            height=42, fg_color="transparent", text_color=("#000000", "#FFFFFF"),
            hover_color=("#D5D5D5", "#383838"),
            command=self.show_setting_view
        )
        self.btn_setting.grid(row=0, column=2, padx=5, pady=8, sticky="ew")

        self.right_margin = ctk.CTkFrame(self, fg_color=("#F0F2F5", "#141414"), corner_radius=0)
        self.right_margin.grid(row=0, column=2, sticky="nsew")

        self.current_view = None
        self.chat_view = ChatView(self.content_frame)
        self.game_view = GameView(self.content_frame)
        self.setting_view = SettingView(self.content_frame, on_save_callback=self.refresh_ai_system)

        self.show_chat_view()

    def ensure_ollama_running(self):
        """Kiểm tra xem Ollama server có đang chạy không, nếu không thì tự động bật."""
        try:
            # Thử gọi một hàm đơn giản của ollama để kiểm tra kết nối server
            ollama.list()
        except Exception:
            # Nếu có lỗi (thường là ConnectionError), nghĩa là server đang tắt
            print("Ollama server is not running. Attempting to start...")
            try:
                # Chạy 'ollama serve' trong nền
                # stdout và stderr được đẩy vào DEVNULL để không hiện cửa sổ CMD đen xì
                subprocess.Popen(
                    ["ollama", "serve"], 
                    stdout=subprocess.DEVNULL, 
                    stderr=subprocess.DEVNULL,
                    shell=True # Cần thiết trên một số bản Windows
                )
                print("Ollama server started successfully.")
            except FileNotFoundError:
                print("Ollama is not installed on this system.")
                # Bạn có thể thêm một thông báo Popup ở đây để báo Trainer cài Ollama

    def init_system_files(self):
        os.makedirs("assets", exist_ok=True)
        os.makedirs("system", exist_ok=True)
        os.makedirs("data", exist_ok=True)

        if not os.path.exists("config.json"):
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump({
                    "ai_name": "Tokai Teio",
                    "user_call": "Trainer",
                    "ai_call": "Em",
                    "model_name": "qwen2.5:1.5b"
                }, f, ensure_ascii=False, indent=4)

        teio_lore_path = "system/teio_lore.txt"
        if not os.path.exists(teio_lore_path):
            with open(teio_lore_path, "w", encoding="utf-8") as f:
                f.write(
                    "[HỒ SƠ NHÂN VẬT: TOKAI TEIO]\n"
                    "- Tên nhân vật: Tokai Teio ('Đế vương miền Đông', 'Bạch diện song vương').\n"
                    "- Tính cách: Năng động, hiếu thắng, nhiệt huyết, cực kỳ quý mến Trainer.\n"
                    "- Huyền thoại: Trải qua chấn thương gãy chân kinh hoàng nhưng đã tạo nên kỳ tích vô địch Arima Kinen 1993.\n"
                    "- Thương hiệu: Kỹ thuật 'Teio Step', rất thích ăn bánh Tart cà rốt và nước mật ong.\n"
                    "- Quy tắc xưng hô: Luôn tự xưng 'em', gọi người dùng là 'Trainer'. Tuyệt đối không dùng 'tôi/bạn'."
                )

        uma_world_path = "system/uma_world.txt"
        if not os.path.exists(uma_world_path):
            with open(uma_world_path, "w", encoding="utf-8") as f:
                f.write(
                    "[THẾ GIỚI UMA MUSUME & KÝ ỨC HỌC VIỆN]\n"
                    "- Bối cảnh: Học viện Tracen, nơi các Uma Musume luyện tập để chinh phục các giải đua Twinkle Series danh giá.\n"
                    "- Mối quan hệ: Kính trọng Hội trưởng Symboli Rudolf, đối thủ kiêm bạn thân Mejiro McQueen, Silence Suzuka.\n"
                    "- Tinh thần: Biến mọi thử thách, bug phần mềm hay thuật toán khó thành các khúc cua trên đường đua để bứt phá."
                )

        user_info_path = "data/user_info.txt"
        if not os.path.exists(user_info_path):
            with open(user_info_path, "w", encoding="utf-8") as f:
                f.write(
                    
                )

    def clear_current_view(self):
        if self.current_view:
            self.current_view.pack_forget()

    def reset_nav_buttons(self):
        default_fg = "transparent"
        text_color = ("#000000", "#FFFFFF")
        self.btn_chat.configure(fg_color=default_fg, text_color=text_color)
        self.btn_game.configure(fg_color=default_fg, text_color=text_color)
        self.btn_setting.configure(fg_color=default_fg, text_color=text_color)

    def show_chat_view(self):
        self.clear_current_view()
        self.reset_nav_buttons()
        self.btn_chat.configure(fg_color="#1f538d", text_color="#FFFFFF")
        self.current_view = self.chat_view
        self.current_view.pack(fill="both", expand=True)

    def show_game_view(self):
        self.clear_current_view()
        self.reset_nav_buttons()
        self.btn_game.configure(fg_color="#1f538d", text_color="#FFFFFF")
        self.current_view = self.game_view
        self.current_view.pack(fill="both", expand=True)

    def show_setting_view(self):
        self.clear_current_view()
        self.reset_nav_buttons()
        self.btn_setting.configure(fg_color="#1f538d", text_color="#FFFFFF")
        self.current_view = self.setting_view
        self.current_view.pack(fill="both", expand=True)

    def refresh_ai_system(self):
        if hasattr(self.chat_view, "reload_system_prompt"):
            self.chat_view.reload_system_prompt()

if __name__ == "__main__":
    app = TokaiTeioApp()
    app.mainloop()
