# Tokai Teio AI Assistant

Chào mừng Trainer đến với ứng dụng **Tokai Teio AI Assistant**! Đây là trợ lý ảo cá nhân nhập vai nhân vật **Tokai Teio** – siêu sao Uma Musume huyền thoại từ *Uma Musume Pretty Derby*. 

Ứng dụng kết hợp giữa mô hình ngôn ngữ chạy cục bộ (Local LLM via Ollama) và giao diện hiện đại, mang đến cho Trainer một người đồng hành mẫn cán, đáng yêu và hoàn toàn riêng tư.

![Version](https://img.shields.io/badge/Version-1.1-blue) 
![Python](https://img.shields.io/badge/Python-3.10+-green) 
![AI](https://img.shields.io/badge/AI-Ollama-orange)
![UI](https://img.shields.io/badge/UI-CustomTkinter-brightgreen)

---

## 🌟 Giới thiệu ứng dụng

**Tokai Teio AI Assistant** được thiết kế với giao diện khung hình điện thoại độc đáo, tái hiện trải nghiệm trò chuyện chân thực và tương tác đa dạng cùng Teio ngay trên máy tính của Trainer:

- 💬 **Trò chuyện nhập vai (Character Chat):** Teio trò chuyện năng động, luôn xưng "Em" và gọi bạn là "Trainer", mang lại cảm giác đồng hành thân thiết.
- 🎮 **Đấu trường Cờ Caro 10x10:** Thử thách trí tuệ với bàn cờ rộng kèm hệ thống bình luận viên Teio cực kỳ hóm hỉnh và sinh động.
- ⚙️ **Tùy chỉnh hệ thống & Ghi chú (Settings):** Linh hoạt thay đổi tên AI, cách xưng hô, đổi model hoặc cập nhật ghi chú cá nhân để Teio hiểu Trainer hơn.
- 🔒 **Bảo mật tuyệt đối 100%:** Toàn bộ dữ liệu và quá trình xử lý AI diễn ra cục bộ trên máy tính, không gửi lên đám mây.

---

## 🛠 Yêu cầu hệ thống

Để ứng dụng chạy mượt mà, máy tính của Trainer cần chuẩn bị:
1. **Python 3.10 trở lên** (Khi cài đặt hãy nhớ tích chọn **"Add Python to PATH"**).
2. **Ollama** (Phần mềm chạy AI cục bộ). Tải tại: [ollama.com](https://ollama.com/).
3. **Model AI:** Mặc định sử dụng `qwen2.5:1.5b` (Nhẹ, tốc độ phản hồi nhanh và thông minh).

---

## 🚀 Hướng dẫn cài đặt chi tiết

### Bước 1: Cài đặt và cấu hình "Bộ nào" AI (Ollama)
1. Tải và cài đặt ứng dụng **Ollama** từ trang chủ [ollama.com](https://ollama.com/) (hỗ trợ Windows, macOS và Linux).
2. Sau khi cài đặt, Ollama sẽ chạy ngầm trên hệ thống. Trainer có thể chọn một trong các cách sau để tải mô hình AI (`qwen2.5:1.5b`) về máy:
   - **Cách 1 (Chạy và tải trực tiếp):** Mở **Command Prompt (CMD)** trên Windows hoặc **Terminal** trên Mac/Linux, sau đó chạy lệnh:
     ```bash
     ollama run qwen2.5:1.5b
     ```
     *(Sau khi tải xong, Trainer có thể nhấn `Ctrl + D` hoặc gõ `/exit` để thoát cửa sổ lệnh).*
   - **Cách 2 (Tải ngầm không mở phiên chat):** Nếu không muốn mở giao diện chat dòng lệnh, Trainer có thể chạy lệnh tải ngầm:
     ```bash
     ollama pull qwen2.5:1.5b
     ```
   - **Cách 3 (Kiểm tra dịch vụ):** Đảm bảo dịch vụ Ollama đang hoạt động bằng cách kiểm tra khay hệ thống (System Tray) hoặc gọi lệnh kiểm tra danh sách model:
     ```bash
     ollama list
     ```

### Bước 2: Cài đặt thư viện Python (Sử dụng `install.bat` hoặc `requirements.txt`)

Trainer có thể lựa chọn 1 trong 2 phương pháp cài đặt thư viện phụ thuộc vào nhu cầu:

- **Cách A: Cài đặt tự động bằng file `install.bat` (Khuyên dùng cho Windows)**
  1. Mở thư mục dự án trên máy tính.
  2. **Nhấp đúp chuột vào file `install.bat`**.
  3. Script sẽ tự động kiểm tra Python, cập nhật `pip` và tự động cài đặt tất cả các thư viện cần thiết (`customtkinter`, `pillow`, `ollama`) mà Trainer không cần gõ lệnh.

- **Cách B: Cài đặt thủ công qua file `requirements.txt` (Dành cho Mac/Linux/Windows)**
  1. Mở **Command Prompt (CMD)** hoặc **Terminal** tại thư mục của dự án.
  2. Chạy lệnh sau để cài đặt toàn bộ danh sách thư viện được liệt kê trong file `requirements.txt`:
     ```bash
     pip install -r requirements.txt
     ```

### Bước 3: Khởi chạy ứng dụng
Sau khi hoàn tất cài đặt, Trainer chỉ cần khởi chạy file chính của ứng dụng:
```bash
python tokai_teio_app.py