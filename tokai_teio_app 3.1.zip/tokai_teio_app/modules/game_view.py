﻿# -*- coding: utf-8 -*-
import random
import os
import customtkinter as ctk
from PIL import Image

class GameView(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.size = 10
        self.win_streak = 5
        self.board = [""] * (self.size * self.size)
        self.human = "❌"
        self.ai = "⭕"
        self.game_over = False

        # Grid layout chính của view
        self.grid_rowconfigure(0, weight=0) # Header
        self.grid_rowconfigure(1, weight=0) # Comment Box
        self.grid_rowconfigure(2, weight=1) # Bàn cờ 10x10
        self.grid_rowconfigure(3, weight=0) # Reset Button
        self.grid_columnconfigure(0, weight=1)

        # 1. Header & Status
        self.header_frame = ctk.CTkFrame(self, fg_color=("#E5E9F0", "#2E3440"), corner_radius=10)
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 2))
        self.header_frame.grid_columnconfigure(1, weight=1)

        self.load_avatar()
        if self.avatar_img:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, image=self.avatar_img, text="")
        else:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, text="🐴", font=("Arial", 18))
        self.avatar_lbl.grid(row=0, column=0, padx=8, pady=6)

        self.title_lbl = ctk.CTkLabel(self.header_frame, text="🔥 Cờ Caro 10x10 (Bình Luận Viên Teio)", font=("Arial", 11, "bold"), text_color="#1f538d")
        self.title_lbl.grid(row=0, column=1, sticky="w", padx=(0, 8))

        # 2. BÌNH LUẬN VIÊN TEIO
        self.comment_card = ctk.CTkFrame(self, fg_color=("#ECEFF4", "#242933"), corner_radius=8)
        self.comment_card.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        
        self.comment_lbl = ctk.CTkLabel(
            self.comment_card, 
            text="Teio: 'Bàn đấu 10x10 rộng thênh thang đã mở! Trainer cẩn thận đừng để em bứt phá qua mặt nhé! 🚀'",
            font=("Arial", 10, "italic"),
            wraplength=380, text_color="#2E3440", justify="center"
        )
        self.comment_lbl.pack(padx=8, pady=6)

        # 3. BÀN CỜ 10x10 (KHÔNG CÓ THANH CUỘN, CÁC Ô VUÔNG CỐ ĐỊNH KÍCH THƯỚC BẰNG NHAU)
        self.board_container = ctk.CTkFrame(self, fg_color=("#D8DEE9", "#3B4252"), corner_radius=12)
        self.board_container.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        
        for i in range(self.size):
            self.board_container.grid_rowconfigure(i, weight=1)
            self.board_container.grid_columnconfigure(i, weight=1)

        self.buttons = []
        for r in range(self.size):
            for c in range(self.size):
                idx = r * self.size + c
                # Dùng width=38, height=38 và sticky="" để khi đánh dấu ❌ ⭕ ô không bị phình/co giãn
                btn = ctk.CTkButton(
                    self.board_container, text="", font=("Arial", 15, "bold"),
                    fg_color=("#FFFFFF", "#2E3440"), hover_color=("#E5E9F0", "#4C566A"),
                    text_color="#1f538d", corner_radius=6, width=38, height=38,
                    command=lambda index=idx: self.human_move(index)
                )
                btn.grid(row=r, column=c, padx=2, pady=2, sticky="")
                self.buttons.append(btn)

        # 4. NÚT CHƠI LẠI
        self.reset_btn = ctk.CTkButton(
            self, text="🔄 Ván Mới 10x10", font=("Arial", 11, "bold"),
            height=34, fg_color="#1f538d", hover_color="#14375e",
            command=self.reset_game
        )
        self.reset_btn.grid(row=3, column=0, sticky="ew", padx=4, pady=(2, 4))

    def load_avatar(self):
        avatar_path = "assets/teio_avatar.png"
        if os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                self.avatar_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(30, 30))
            except Exception:
                self.avatar_img = None
        else:
            self.avatar_img = None

    def update_commentary(self, event_type):
        human_comments = [
            "Teio: 'Nước đi hay đấy Trainer! Nhưng không qua mắt đế vương này đâu nhé! 🧐'",
            "Teio: 'Á à! Định tạo chuỗi 5 quân bẫy em sao? Còn lâu nha! ✨'",
            "Teio: 'Tốc độ đi cờ của Trainer mượt mà như Teio Step vậy! 🚀'",
            "Teio: 'Nước đi cao tay quá... Em phải tập trung cao độ mới được! 🔥'",
            "Teio: 'Hừm, Trainer chơi khó thế nhỉ? Để em suy nghĩ xem nào... 🤔'",
            "Teio: 'Êm ru! Nước đi này của Trainer rất có tiềm năng trên đường đua đấy! '",
            "Teio: 'Đừng có chủ quan nha Trainer, em đang gài thế ngược lại đấy! 😎'",
            "Teio: 'Chà chà, nước cờ này sắc bén như dao cạo luôn! ⚔️'",
            "Teio: 'Trainer định vượt mặt em ở khúc cua này à? Mơ đi cưng! 😜'",
            "Teio: 'Một pha xử lý mang đậm dấu ấn của lập trình viên cừ khôi! 💻'"
        ]

        ai_comments = [
            "Teio: 'Em vừa đi một nước chặn đường tiến công hoàn hảo! Sợ chưa? 😎'",
            "Teio: 'Cú bứt tốc kiểu Teio Step! Đố Trainer bắt kịp em đấy! ⚡'",
            "Teio: 'Hahaha, bàn cờ này đang nằm trong tầm kiểm soát của em rồi! 🎯'",
            "Teio: 'Em đặt quân ở đây là Trainer hết đường thoát hiểm nhé! 🚧'",
            "Teio: 'Đế vương miền Đông ra tay là chỉ có chuẩn xác từng milimet! 👑'",
            "Teio: 'Em vừa tạo ra một thế cờ hiểm hóc cực kỳ luôn, đoán xem ở đâu nào? 🧩'",
            "Teio: 'Chặn ngay lập tức! Không cho Trainer mộng mơ nữa nhé! 🛑'",
            "Teio: 'Một nước cờ mang tính sát thương cao từ Teio! 💥'",
            "Teio: 'Trainer thấy nước đi vừa rồi của em có mượt mà không nào? ✨'",
            "Teio: 'Đội hình tấn công của em đã sẵn sàng càn quét bàn cờ rồi đây! 🚀'"
        ]

        if event_type == "human_move":
            msg = random.choice(human_comments)
        elif event_type == "ai_move":
            msg = random.choice(ai_comments)
        else:
            msg = ""
        self.comment_lbl.configure(text=msg)

    def human_move(self, idx):
        if self.board[idx] == "" and not self.game_over:
            self.board[idx] = self.human
            self.buttons[idx].configure(text=self.human, text_color="#D81B60")
            
            if self.check_win(self.board, self.human):
                self.end_game("win")
                return
            elif "" not in self.board:
                self.end_game("draw")
                return

            self.update_commentary("human_move")
            self.after(300, self.ai_move)

    def ai_move(self):
        if self.game_over:
            return

        best_move = self.find_best_move()
        if best_move is not None:
            self.board[best_move] = self.ai
            self.buttons[best_move].configure(text=self.ai, text_color="#1E88E5")

            if self.check_win(self.board, self.ai):
                self.end_game("lose")
                return
            elif "" not in self.board:
                self.end_game("draw")
                return

            self.update_commentary("ai_move")

    def find_best_move(self):
        empty_cells = [i for i, cell in enumerate(self.board) if cell == ""]
        if not empty_cells:
            return None

        for idx in empty_cells:
            self.board[idx] = self.ai
            if self.check_win(self.board, self.ai):
                self.board[idx] = ""
                return idx
            self.board[idx] = ""

        for idx in empty_cells:
            self.board[idx] = self.human
            if self.check_win(self.board, self.human):
                self.board[idx] = ""
                return idx
            self.board[idx] = ""

        best_score = -1
        best_moves = []

        for idx in empty_cells:
            score = self.evaluate_cell(idx, self.ai) + self.evaluate_cell(idx, self.human) * 0.95
            if score > best_score:
                best_score = score
                best_moves = [idx]
            elif score == best_score:
                best_moves.append(idx)

        return random.choice(best_moves) if best_moves else random.choice(empty_cells)

    def evaluate_cell(self, idx, mark):
        r, c = divmod(idx, self.size)
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        score = 0
        for dr, dc in directions:
            count = 0
            for step in range(1, 5):
                nr, nc = r + dr * step, c + dc * step
                if 0 <= nr < self.size and 0 <= nc < self.size:
                    if self.board[nr * self.size + nc] == mark:
                        count += 1
                    else:
                        break
                else:
                    break
            for step in range(1, 5):
                nr, nc = r - dr * step, c - dc * step
                if 0 <= nr < self.size and 0 <= nc < self.size:
                    if self.board[nr * self.size + nc] == mark:
                        count += 1
                    else:
                        break
                else:
                    break
            score += count * count
        return score

    def check_win(self, b, mark):
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for r in range(self.size):
            for c in range(self.size):
                if b[r * self.size + c] == mark:
                    for dr, dc in directions:
                        win = True
                        for step in range(1, self.win_streak):
                            nr, nc = r + dr * step, c + dc * step
                            if not (0 <= nr < self.size and 0 <= nc < self.size) or b[nr * self.size + nc] != mark:
                                win = False
                                break
                        if win:
                            return True
        return False

    def end_game(self, result):
        self.game_over = True
        
        win_end_comments = [
            "Teio: 'Huhu... Trainer đánh đỉnh quá! Em thua tâm phục khẩu phục trên bàn 10x10 rồi! 😭'",
            "Teio: 'Oa oà... Thua mất tiêu rồi! Trainer gian lận hay do Trainer quá giỏi thế hả? 🥺'",
            "Teio: 'Em phục sát đất luôn á! Trainer chính là Bá Vương cờ caro thực thụ rồi! 🏆'"
        ]

        lose_end_comments = [
            "Teio: 'Hahaha! Thắng rồi! Nối đủ 5 quân trước là nghệ thuật đỉnh cao của Teio! 👑✨'",
            "Teio: 'Đã bảo là đường đua này thuộc về em cơ mà! Trainer thấy cú bứt tốc chưa? 😎'",
            "Teio: 'Yeahhh! Thắng oanh liệt luôn! Trainer chuẩn bị nhận hình phạt chép phạt đi nha! 📝'"
        ]

        draw_end_comments = [
            "Teio: 'Bất phân thắng bại! Đúng là đối thủ ngang tài ngang sức với Teio! 🤝'",
            "Teio: 'Hòa nhau thế này thì ấm ức ghê, phải đấu lại ngay lập tức thôi! 🔂'",
            "Teio: 'Kẻ tám lạng người nửa cân, không ai chịu nhường ai luôn á! ⚖️'"
        ]

        if result == "win":
            msg = random.choice(win_end_comments)
        elif result == "lose":
            msg = random.choice(lose_end_comments)
        else:
            msg = random.choice(draw_end_comments)

        self.comment_lbl.configure(text=msg)
        self.show_victory_popup(result, msg)

    def show_victory_popup(self, result, end_comment):
        popup = ctk.CTkToplevel(self)
        popup.title("KẾT QUẢ TRẬN ĐẤU 10x10")
        popup.geometry("340x360")
        popup.grab_set()
        popup.resizable(False, False)

        if result == "win":
            title_text = "🎉 TRAINER CHIẾN THẮNG!"
            status_color = "#2ecc71"
        elif result == "lose":
            title_text = "👑 TEIO CHIẾN THẮNG!"
            status_color = "#e74c3c"
        else:
            title_text = "🤝 BẤT PHÂN THẮNG BẠI!"
            status_color = "#f39c12"

        card = ctk.CTkFrame(popup, fg_color=("#F8F9FA", "#1E1E1E"), corner_radius=12)
        card.pack(fill="both", expand=True, padx=10, pady=10)

        if self.avatar_img:
            img_lbl = ctk.CTkLabel(card, image=self.avatar_img, text="")
        else:
            img_lbl = ctk.CTkLabel(card, text="🏆", font=("Arial", 40))
        img_lbl.pack(pady=(12, 4))

        t_lbl = ctk.CTkLabel(card, text=title_text, font=("Arial", 13, "bold"), text_color=status_color)
        t_lbl.pack(pady=4)

        s_lbl = ctk.CTkLabel(card, text=end_comment, font=("Arial", 10, "italic"), wraplength=280, justify="center")
        s_lbl.pack(pady=6, padx=10)

        btn_replay = ctk.CTkButton(
            card, text="🔄 Đấu Lại Ván 10x10 Mới", font=("Arial", 11, "bold"),
            fg_color=status_color, height=36,
            command=lambda: [popup.destroy(), self.reset_game()]
        )
        btn_replay.pack(pady=10, fill="x", padx=20)

    def reset_game(self):
        self.board = [""] * (self.size * self.size)
        self.game_over = False
        for btn in self.buttons:
            btn.configure(text="", fg_color=("#FFFFFF", "#2E3440"))
        self.comment_lbl.configure(text="Teio: 'Ván đấu 10x10 mới bắt đầu! Lần này em sẽ không nhường nữa đâu nhé! 🚀'")# -*- coding: utf-8 -*-
import random
import os
import customtkinter as ctk
from PIL import Image

class GameView(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.size = 10
        self.win_streak = 5
        self.board = [""] * (self.size * self.size)
        self.human = "❌"
        self.ai = "⭕"
        self.game_over = False

        # Grid layout chính của view
        self.grid_rowconfigure(0, weight=0) # Header
        self.grid_rowconfigure(1, weight=0) # Comment Box
        self.grid_rowconfigure(2, weight=1) # Bàn cờ 10x10
        self.grid_rowconfigure(3, weight=0) # Reset Button
        self.grid_columnconfigure(0, weight=1)

        # 1. Header & Status
        self.header_frame = ctk.CTkFrame(self, fg_color=("#E5E9F0", "#2E3440"), corner_radius=10)
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 2))
        self.header_frame.grid_columnconfigure(1, weight=1)

        self.load_avatar()
        if self.avatar_img:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, image=self.avatar_img, text="")
        else:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, text="🐴", font=("Arial", 18))
        self.avatar_lbl.grid(row=0, column=0, padx=8, pady=6)

        self.title_lbl = ctk.CTkLabel(self.header_frame, text="🔥 Cờ Caro 10x10 (Bình Luận Viên Teio)", font=("Arial", 11, "bold"), text_color="#1f538d")
        self.title_lbl.grid(row=0, column=1, sticky="w", padx=(0, 8))

        # 2. BÌNH LUẬN VIÊN TEIO
        self.comment_card = ctk.CTkFrame(self, fg_color=("#ECEFF4", "#242933"), corner_radius=8)
        self.comment_card.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        
        self.comment_lbl = ctk.CTkLabel(
            self.comment_card, 
            text="Teio: 'Bàn đấu 10x10 rộng thênh thang đã mở! Trainer cẩn thận đừng để em bứt phá qua mặt nhé! 🚀'",
            font=("Arial", 10, "italic"),
            wraplength=380, text_color="#2E3440", justify="center"
        )
        self.comment_lbl.pack(padx=8, pady=6)

        # 3. BÀN CỜ 10x10 (KHÔNG CÓ THANH CUỘN, CÁC Ô VUÔNG CỐ ĐỊNH KÍCH THƯỚC BẰNG NHAU)
        self.board_container = ctk.CTkFrame(self, fg_color=("#D8DEE9", "#3B4252"), corner_radius=12)
        self.board_container.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        
        for i in range(self.size):
            self.board_container.grid_rowconfigure(i, weight=1)
            self.board_container.grid_columnconfigure(i, weight=1)

        self.buttons = []
        for r in range(self.size):
            for c in range(self.size):
                idx = r * self.size + c
                # Dùng width=38, height=38 và sticky="" để khi đánh dấu ❌ ⭕ ô không bị phình/co giãn
                btn = ctk.CTkButton(
                    self.board_container, text="", font=("Arial", 15, "bold"),
                    fg_color=("#FFFFFF", "#2E3440"), hover_color=("#E5E9F0", "#4C566A"),
                    text_color="#1f538d", corner_radius=6, width=38, height=38,
                    command=lambda index=idx: self.human_move(index)
                )
                btn.grid(row=r, column=c, padx=2, pady=2, sticky="")
                self.buttons.append(btn)

        # 4. NÚT CHƠI LẠI
        self.reset_btn = ctk.CTkButton(
            self, text="🔄 Ván Mới 10x10", font=("Arial", 11, "bold"),
            height=34, fg_color="#1f538d", hover_color="#14375e",
            command=self.reset_game
        )
        self.reset_btn.grid(row=3, column=0, sticky="ew", padx=4, pady=(2, 4))

    def load_avatar(self):
        avatar_path = "assets/teio_avatar.png"
        if os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                self.avatar_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(30, 30))
            except Exception:
                self.avatar_img = None
        else:
            self.avatar_img = None

    def update_commentary(self, event_type):
        human_comments = [
            "Teio: 'Nước đi hay đấy Trainer! Nhưng không qua mắt đế vương này đâu nhé! 🧐'",
            "Teio: 'Á à! Định tạo chuỗi 5 quân bẫy em sao? Còn lâu nha! ✨'",
            "Teio: 'Tốc độ đi cờ của Trainer mượt mà như Teio Step vậy! 🚀'",
            "Teio: 'Nước đi cao tay quá... Em phải tập trung cao độ mới được! 🔥'",
            "Teio: 'Hừm, Trainer chơi khó thế nhỉ? Để em suy nghĩ xem nào... 🤔'",
            "Teio: 'Êm ru! Nước đi này của Trainer rất có tiềm năng trên đường đua đấy! 🐎'",
            "Teio: 'Đừng có chủ quan nha Trainer, em đang gài thế ngược lại đấy! 😎'",
            "Teio: 'Chà chà, nước cờ này sắc bén như dao cạo luôn! ⚔️'",
            "Teio: 'Trainer định vượt mặt em ở khúc cua này à? Mơ đi cưng! 😜'",
            "Teio: 'Một pha xử lý mang đậm dấu ấn của lập trình viên cừ khôi! 💻'"
        ]

        ai_comments = [
            "Teio: 'Em vừa đi một nước chặn đường tiến công hoàn hảo! Sợ chưa? 😎'",
            "Teio: 'Cú bứt tốc kiểu Teio Step! Đố Trainer bắt kịp em đấy! ⚡'",
            "Teio: 'Hahaha, bàn cờ này đang nằm trong tầm kiểm soát của em rồi! 🎯'",
            "Teio: 'Em đặt quân ở đây là Trainer hết đường thoát hiểm nhé! 🚧'",
            "Teio: 'Đế vương miền Đông ra tay là chỉ có chuẩn xác từng milimet! 👑'",
            "Teio: 'Em vừa tạo ra một thế cờ hiểm hóc cực kỳ luôn, đoán xem ở đâu nào? 🧩'",
            "Teio: 'Chặn ngay lập tức! Không cho Trainer mộng mơ nữa nhé! 🛑'",
            "Teio: 'Một nước cờ mang tính sát thương cao từ Teio! 💥'",
            "Teio: 'Trainer thấy nước đi vừa rồi của em có mượt mà không nào? ✨'",
            "Teio: 'Đội hình tấn công của em đã sẵn sàng càn quét bàn cờ rồi đây! 🚀'"
        ]

        if event_type == "human_move":
            msg = random.choice(human_comments)
        elif event_type == "ai_move":
            msg = random.choice(ai_comments)
        else:
            msg = ""
        self.comment_lbl.configure(text=msg)

    def human_move(self, idx):
        if self.board[idx] == "" and not self.game_over:
            self.board[idx] = self.human
            self.buttons[idx].configure(text=self.human, text_color="#D81B60")
            
            if self.check_win(self.board, self.human):
                self.end_game("win")
                return
            elif "" not in self.board:
                self.end_game("draw")
                return

            self.update_commentary("human_move")
            self.after(300, self.ai_move)

    def ai_move(self):
        if self.game_over:
            return

        best_move = self.find_best_move()
        if best_move is not None:
            self.board[best_move] = self.ai
            self.buttons[best_move].configure(text=self.ai, text_color="#1E88E5")

            if self.check_win(self.board, self.ai):
                self.end_game("lose")
                return
            elif "" not in self.board:
                self.end_game("draw")
                return

            self.update_commentary("ai_move")

    def find_best_move(self):
        empty_cells = [i for i, cell in enumerate(self.board) if cell == ""]
        if not empty_cells:
            return None

        for idx in empty_cells:
            self.board[idx] = self.ai
            if self.check_win(self.board, self.ai):
                self.board[idx] = ""
                return idx
            self.board[idx] = ""

        for idx in empty_cells:
            self.board[idx] = self.human
            if self.check_win(self.board, self.human):
                self.board[idx] = ""
                return idx
            self.board[idx] = ""

        best_score = -1
        best_moves = []

        for idx in empty_cells:
            score = self.evaluate_cell(idx, self.ai) + self.evaluate_cell(idx, self.human) * 0.95
            if score > best_score:
                best_score = score
                best_moves = [idx]
            elif score == best_score:
                best_moves.append(idx)

        return random.choice(best_moves) if best_moves else random.choice(empty_cells)

    def evaluate_cell(self, idx, mark):
        r, c = divmod(idx, self.size)
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        score = 0
        for dr, dc in directions:
            count = 0
            for step in range(1, 5):
                nr, nc = r + dr * step, c + dc * step
                if 0 <= nr < self.size and 0 <= nc < self.size:
                    if self.board[nr * self.size + nc] == mark:
                        count += 1
                    else:
                        break
                else:
                    break
            for step in range(1, 5):
                nr, nc = r - dr * step, c - dc * step
                if 0 <= nr < self.size and 0 <= nc < self.size:
                    if self.board[nr * self.size + nc] == mark:
                        count += 1
                    else:
                        break
                else:
                    break
            score += count * count
        return score

    def check_win(self, b, mark):
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for r in range(self.size):
            for c in range(self.size):
                if b[r * self.size + c] == mark:
                    for dr, dc in directions:
                        win = True
                        for step in range(1, self.win_streak):
                            nr, nc = r + dr * step, c + dc * step
                            if not (0 <= nr < self.size and 0 <= nc < self.size) or b[nr * self.size + nc] != mark:
                                win = False
                                break
                        if win:
                            return True
        return False

    def end_game(self, result):
        self.game_over = True
        
        win_end_comments = [
            "Teio: 'Huhu... Trainer đánh đỉnh quá! Em thua tâm phục khẩu phục trên bàn 10x10 rồi! 😭'",
            "Teio: 'Oa oà... Thua mất tiêu rồi! Trainer gian lận hay do Trainer quá giỏi thế hả? 🥺'",
            "Teio: 'Em phục sát đất luôn á! Trainer chính là Bá Vương cờ caro thực thụ rồi! 🏆'"
        ]

        lose_end_comments = [
            "Teio: 'Hahaha! Thắng rồi! Nối đủ 5 quân trước là nghệ thuật đỉnh cao của Teio! 👑✨'",
            "Teio: 'Đã bảo là đường đua này thuộc về em cơ mà! Trainer thấy cú bứt tốc chưa? 😎'",
            "Teio: 'Yeahhh! Thắng oanh liệt luôn! Trainer chuẩn bị nhận hình phạt chép phạt đi nha! 📝'"
        ]

        draw_end_comments = [
            "Teio: 'Bất phân thắng bại! Đúng là đối thủ ngang tài ngang sức với Teio! 🤝'",
            "Teio: 'Hòa nhau thế này thì ấm ức ghê, phải đấu lại ngay lập tức thôi! 🔂'",
            "Teio: 'Kẻ tám lạng người nửa cân, không ai chịu nhường ai luôn á! ⚖️'"
        ]

        if result == "win":
            msg = random.choice(win_end_comments)
        elif result == "lose":
            msg = random.choice(lose_end_comments)
        else:
            msg = random.choice(draw_end_comments)

        self.comment_lbl.configure(text=msg)
        self.show_victory_popup(result, msg)

    def show_victory_popup(self, result, end_comment):
        popup = ctk.CTkToplevel(self)
        popup.title("KẾT QUẢ TRẬN ĐẤU 10x10")
        popup.geometry("340x360")
        popup.grab_set()
        popup.resizable(False, False)

        if result == "win":
            title_text = "🎉 TRAINER CHIẾN THẮNG!"
            status_color = "#2ecc71"
        elif result == "lose":
            title_text = "👑 TEIO CHIẾN THẮNG!"
            status_color = "#e74c3c"
        else:
            title_text = "🤝 BẤT PHÂN THẮNG BẠI!"
            status_color = "#f39c12"

        card = ctk.CTkFrame(popup, fg_color=("#F8F9FA", "#1E1E1E"), corner_radius=12)
        card.pack(fill="both", expand=True, padx=10, pady=10)

        if self.avatar_img:
            img_lbl = ctk.CTkLabel(card, image=self.avatar_img, text="")
        else:
            img_lbl = ctk.CTkLabel(card, text="🏆", font=("Arial", 40))
        img_lbl.pack(pady=(12, 4))

        t_lbl = ctk.CTkLabel(card, text=title_text, font=("Arial", 13, "bold"), text_color=status_color)
        t_lbl.pack(pady=4)

        s_lbl = ctk.CTkLabel(card, text=end_comment, font=("Arial", 10, "italic"), wraplength=280, justify="center")
        s_lbl.pack(pady=6, padx=10)

        btn_replay = ctk.CTkButton(
            card, text="🔄 Đấu Lại Ván 10x10 Mới", font=("Arial", 11, "bold"),
            fg_color=status_color, height=36,
            command=lambda: [popup.destroy(), self.reset_game()]
        )
        btn_replay.pack(pady=10, fill="x", padx=20)

    def reset_game(self):
        self.board = [""] * (self.size * self.size)
        self.game_over = False
        for btn in self.buttons:
            btn.configure(text="", fg_color=("#FFFFFF", "#2E3440"))
        self.comment_lbl.configure(text="Teio: 'Ván đấu 10x10 mới bắt đầu! Lần này em sẽ không nhường nữa đâu nhé! 🚀'")