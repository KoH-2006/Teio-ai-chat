﻿# -*- coding: utf-8 -*-
import random
import os
import customtkinter as ctk
from PIL import Image

class GameView(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.size = 10
        self.win_streak = 5
        self.board = [""] * (self.size * self.size)
        self.human = "❌"
        self.ai = "⭕"
        self.game_over = False

        # Grid layout
        self.grid_rowconfigure(0, weight=0) # Header
        self.grid_rowconfigure(1, weight=0) # Comment Box
        self.grid_rowconfigure(2, weight=1) # Board 10x10
        self.grid_rowconfigure(3, weight=0) # Reset Button
        self.grid_columnconfigure(0, weight=1)

        # 1. Header & Status
        self.header_frame = ctk.CTkFrame(self, fg_color=("#E5E9F0", "#2E3440"), corner_radius=10)
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 2))
        self.header_frame.grid_columnconfigure(1, weight=1)

        self.load_avatar()
        if self.avatar_img:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, image=self.avatar_img, text="")
        else:
            self.avatar_lbl = ctk.CTkLabel(self.header_frame, text="🐴", font=("Arial", 18))
        self.avatar_lbl.grid(row=0, column=0, padx=8, pady=6)

        self.title_lbl = ctk.CTkLabel(self.header_frame, text="🔥 Cờ Caro 10x10 (Bình Luận Viên Teio)", font=("Arial", 11, "bold"), text_color="#1f538d")
        self.title_lbl.grid(row=0, column=1, sticky="w", padx=(0, 8))

        # 2. BÌNH LUẬN VIÊN TEIO (Kho tàng hơn 100+ kiểu thoại phong phú)
        self.comment_card = ctk.CTkFrame(self, fg_color=("#ECEFF4", "#242933"), corner_radius=8)
        self.comment_card.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        
        self.comment_lbl = ctk.CTkLabel(
            self.comment_card, 
            text="Teio: 'Bàn đấu 10x10 rộng thênh thang đã mở! Trainer cẩn thận đừng để em bứt phá qua mặt nhé! 🚀'",
            font=("Arial", 10, "italic"),
            wraplength=380, text_color="#2E3440", justify="center"
        )
        self.comment_lbl.pack(padx=8, pady=6)

        # 3. BÀN CỜ 10x10 GRID
        self.board_container = ctk.CTkScrollableFrame(self, fg_color=("#D8DEE9", "#3B4252"), corner_radius=12)
        self.board_container.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        
        for i in range(self.size):
            self.board_container.grid_rowconfigure(i, weight=1)
            self.board_container.grid_columnconfigure(i, weight=1)

        self.buttons = []
        for r in range(self.size):
            for c in range(self.size):
                idx = r * self.size + c
                btn = ctk.CTkButton(
                    self.board_container, text="", font=("Arial", 11, "bold"),
                    fg_color=("#FFFFFF", "#2E3440"), hover_color=("#E5E9F0", "#4C566A"),
                    text_color="#1f538d", corner_radius=4, width=30, height=30,
                    command=lambda index=idx: self.human_move(index)
                )
                btn.grid(row=r, column=c, padx=1, pady=1, sticky="nsew")
                self.buttons.append(btn)

        # 4. NÚT CHƠI LẠI
        self.reset_btn = ctk.CTkButton(
            self, text="🔄 Ván Mới 10x10", font=("Arial", 11, "bold"),
            height=34, fg_color="#1f538d", hover_color="#14375e",
            command=self.reset_game
        )
        self.reset_btn.grid(row=3, column=0, sticky="ew", padx=4, pady=(2, 4))

    def load_avatar(self):
        avatar_path = "assets/teio_avatar.png"
        if os.path.exists(avatar_path):
            try:
                pil_img = Image.open(avatar_path)
                self.avatar_img = ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(30, 30))
            except Exception:
                self.avatar_img = None
        else:
            self.avatar_img = None

    def update_commentary(self, event_type):
        # Kho tàng hơn 100+ kiểu thoại phong phú cho Teio trong lúc đánh
        human_comments = [
            "Teio: 'Nước đi hay đấy Trainer! Nhưng không qua mắt đế vương này đâu nhé! 🧐'",
            "Teio: 'Á à! Định tạo chuỗi 5 quân bẫy em sao? Còn lâu nha! ✨'",
            "Teio: 'Tốc độ đi cờ của Trainer mượt mà như Teio Step vậy! 🚀'",
            "Teio: 'Nước đi cao tay quá... Em phải tập trung cao độ mới được! 🔥'",
            "Teio: 'Hừm, Trainer chơi khó thế nhỉ? Để em suy nghĩ xem nào... 🤔'",
            "Teio: 'Êm ru! Nước đi này của Trainer rất có tiềm năng trên đường đua đấy! 🐎'",
            "Teio: 'Đừng có chủ quan nha Trainer, em đang gài thế ngược lại đấy! 😎'",
            "Teio: 'Chà chà, nước cờ này sắc bén như dao cạo luôn! ⚔️'",
            "Teio: 'Trainer định vượt mặt em ở khúc cua này à? Mơ đi cưng! 😜'",
            "Teio: 'Một pha xử lý mang đậm dấu ấn của lập trình viên cừ khôi! 💻'",
            "Teio: 'Em ngửi thấy mùi nguy hiểm rồi đấy... nhưng em không sợ đâu! 💪'",
            "Teio: 'Nước đi này thông minh phết nhờ! Em bắt đầu thấy hào hứng rồi đấy! ✨'",
            "Teio: 'Trainer cứ từ từ thong thả, chiến thắng cuối cùng vẫn là của em thôi! 👑'",
            "Teio: 'Ủa ủa? Đánh kiểu này là tính lừa em sập bẫy hả Trainer? 😮'",
            "Teio: 'Tay cầm bàn phím code code mà đánh cờ cũng hiểm ác phết! 😆'",
            "Teio: 'Đường đua 10x10 này rộng thật, nhưng tầm nhìn của em bao quát hết! 🔭'",
            "Teio: 'Nước cờ chắc nịch thế cơ á? Để em tìm đường lách qua xem nào! 🔍'",
            "Teio: 'Tuyệt cú mèo! Trainer làm em phải trầm trồ rồi đấy! 🌟'",
            "Teio: 'Đừng có tưởng bở nha, em đã tính trước 4 bước rồi đấy! 🎯'",
            "Teio: 'Một nước đi rất thể thao và fair-play! Em thích thế! 🤝'",
            "Teio: 'Trainer đang định dồn em vào chân tường à? Không dễ thế đâu! 🛡️'",
            "Teio: 'Cẩn thận đấy nhé, em sắp tung đòn phản công chớp nhoáng rồi! ⚡'",
            "Teio: 'Nhìn cách Trainer đi cờ là biết hay ho rồi, nhưng em sẽ phá sản nó! 💥'",
            "Teio: 'Trận đấu đang kịch tính nghẹt thở luôn á! Tim em đập thình thịch nè! 💓'",
            "Teio: 'Trainer tài năng thế này bảo sao em cứ quấn quýt không rời! 🥰'",
            "Teio: 'Nước cờ này vừa nhanh vừa hiểm, đúng là phong cách của Trainer nhà ta! 🏆'",
            "Teio: 'Em vừa uống ngụm nước mật ong hồi sức xong, giờ thì chấp Trainer 3 bước! 🍯'",
            "Teio: 'Đừng có hòng qua mặt em ở ô trống đó nha Trainer! 🛑'",
            "Teio: 'Sắp xếp đội hình quân cờ đẹp thế nhở, nhưng em sẽ quậy tung lên đây! 🌪️'",
            "Teio: 'Trainer chơi chiêu này độc đáo thật đấy, em ghi nhận nhé! 📝'",
            "Teio: 'Cố lên Trainer ơi, đừng để thua em chóng vánh quá nha! 🤭'",
            "Teio: 'Gió đang đổi chiều rồi đấy, Trainer chuẩn bị tinh thần đi! 🌬️'",
            "Teio: 'Đường đua Nakayama huyền thoại còn vượt qua được, sợ gì bàn cờ này! 🏇'",
            "Teio: 'Một cú lật kèo ngoạn mục đang chờ Trainer ở phía trước đấy! 🔄'",
            "Teio: 'Trainer đi cờ điệu nghệ ghê, nhưng em là thiên tài cơ mà! 😌'",
            "Teio: 'Không khí căng thẳng quá nhỉ? Hay mình làm ly mật ong rồi tính tiếp? 🥤'",
            "Teio: 'Em đang soi từng ô trống trên bàn cờ để tìm sơ hở của Trainer đây! 🔎'",
            "Teio: 'Đừng hòng ép góc được Teio nha, em uyển chuyển lắm đấy! 💃'",
            "Teio: 'Nước đi vừa rồi làm em giật mình thon thót luôn á! 😱'",
            "Teio: 'Trainer cứ từ từ đánh, chiến thắng sớm muộn gì cũng gọi tên em mà! 🎈'",
            "Teio: 'Bánh tart cà rốt đang vẫy gọi em sau trận thắng này đấy! 🥕'",
            "Teio: 'Đòn này hiểm đấy, nhưng em đã hóa giải thành công rồi nhé! 🛡️'",
            "Teio: 'Chà, đối thủ xứng tầm đây chứ đâu xa! Thích thật đấy! 💖'",
            "Teio: 'Trainer tập trung cao độ chưa kìa? Trông đáng yêu phết! 😉'",
            "Teio: 'Em sẽ không nhường bước đâu nha, cẩn thận đấy! 🔥'",
            "Teio: 'Một pha đặt quân mang tính chiến lược toàn cầu luôn! 🌐'",
            "Teio: 'Trainer chơi chiêu này hơi bị được đấy, để em xem xét kỹ lại đã! 🤔'",
            "Teio: 'Đường đua dài hơi 10x10 này ai bền sức hơn người đó thắng! 🏃‍♀️'",
            "Teio: 'Em đang nở nụ cười chiến thắng rồi đấy, Trainer thấy chưa? 😁'",
            "Teio: 'Hơi bị nể Trainer khoản đi cờ chớp nhoáng này rồi nha! 👏'"
        ]

        ai_comments = [
            "Teio: 'Em vừa đi một nước chặn đường tiến công hoàn hảo! Sợ chưa? 😎'",
            "Teio: 'Cú bứt tốc kiểu Teio Step! Đố Trainer bắt kịp em đấy! ⚡'",
            "Teio: 'Hahaha, bàn cờ này đang nằm trong tầm kiểm soát của em rồi! 🎯'",
            "Teio: 'Em đặt quân ở đây là Trainer hết đường thoát hiểm nhé! 🚧'",
            "Teio: 'Đế vương miền Đông ra tay là chỉ có chuẩn xác từng milimet! 👑'",
            "Teio: 'Em vừa tạo ra một thế cờ hiểm hóc cực kỳ luôn, đoán xem ở đâu nào? 🧩'",
            "Teio: 'Chặn ngay lập tức! Không cho Trainer mộng mơ nữa nhé! 🛑'",
            "Teio: 'Một nước cờ mang tính sát thương cao từ Teio! 💥'",
            "Teio: 'Trainer thấy nước đi vừa rồi của em có mượt mà không nào? ✨'",
            "Teio: 'Đội hình tấn công của em đã sẵn sàng càn quét bàn cờ rồi đây! 🚀'",
            "Teio: 'Em nhẹ nhàng đặt một quân vào đây và... boom! Bẫy đã mở! 💣'",
            "Teio: 'Thế cờ này đẹp như tranh vẽ và nguy hiểm như dao sắc! 🎨⚔️'",
            "Teio: 'Trainer đoán xem em định nối dài chuỗi mấy quân nào? 🔢'",
            "Teio: 'Sự phụ trội về chiến thuật lúc nào cũng mang lại chiến thắng tuyệt đối! 🧠'",
            "Teio: 'Em vừa khóa chặt đường lui của Trainer rồi đấy nhé! 🔒'",
            "Teio: 'Nước đi chớp nhoáng làm đối thủ phải lác mắt luôn! 👀'",
            "Teio: 'Trainer cẩn thận kẻo sập bẫy tinh vi của em nha! 🪤'",
            "Teio: 'Đẳng cấp của một Uma Musume hàng đầu là đây chứ đâu! 🌟'",
            "Teio: 'Em cười thế thôi chứ trong đầu đang tính toán chiến lược ghê lắm đấy! 😈'",
            "Teio: 'Một bước tiến vững chắc hướng thẳng tới vạch đích chiến thắng! 🏁'",
            "Teio: 'Trainer đừng có mải ngắm em mà quên phòng thủ đấy nhé! 😉'",
            "Teio: 'Em vừa bẻ lái cực gắt ở góc bàn cờ này, siêu chưa? 🏎️'",
            "Teio: 'Thắng thua chưa biết chừng, nhưng hiện tại em đang nắm thế thượng phong! 📈'",
            "Teio: 'Em gieo một nỗi sợ nho nhỏ vào chiến thuật của Trainer nè! 👻'",
            "Teio: 'Quân cờ này chính là chìa khóa mở cánh cửa chiến thắng cho em! 🔑'",
            "Teio: 'Trainer chuẩn bị tinh thần chịu thua trước vẻ đẹp và trí tuệ của em đi! 💃'",
            "Teio: 'Không một kẽ hở! Em phòng thủ và phản công cùng một lúc luôn! 🛡️⚔️'",
            "Teio: 'Nước đi này làm đối thủ phải khóc thét vì quá tinh ranh! 😭'",
            "Teio: 'Em đang phi nước đại về đích rồi, Trainer mau rượt theo đi! 🐎💨'",
            "Teio: 'Cảm giác thống trị bàn cờ 10x10 này thật là tuyệt vời! 🌅'",
            "Teio: 'Trainer lỡ nhịp rồi nhé, giờ là lúc em tỏa sáng! 🌟'",
            "Teio: 'Một nước đi đơn giản nhưng ẩn chứa sát khí ngập tràn! 🔪'",
            "Teio: 'Em vừa bóp nghẹt mọi hy vọng lật kèo của Trainer luôn! 📉'",
            "Teio: 'Đỉnh cao của chiến thuật chính là làm cho đối thủ bất lực! 🧘‍♀️'",
            "Teio: 'Trainer thấy sự lợi hại của em chưa nào? Quá đỉnh đúng không! 😎'",
            "Teio: 'Em cứ điềm tĩnh thế thôi mà Trainer sắp toát mồ hôi hột rồi kìa! 😅'",
            "Teio: 'Một pha lập trình logic bằng quân cờ không chê vào đâu được! 💻✨'",
            "Teio: 'Đường đua này chỉ có một vị trí quán quân, và đó là em! 🥇'",
            "Teio: 'Em bẫy chỗ này một chút, gài chỗ kia một tí là hoàn hảo! 📐'",
            "Teio: 'Trainer đừng hòng tìm ra lỗ hổng trong phòng tuyến của em! 🧱'",
            "Teio: 'Cú đánh úp bất ngờ khiến Trainer trở tay không kịp! ⚡'",
            "Teio: 'Em đang dẫn trước một bước rồi nha, cố rượt theo đi Trainer ơi! 🏃‍♂️'",
            "Teio: 'Sự thông minh này đôi khi cũng làm em thấy phiền vì quá nổi bật! 🤭'",
            "Teio: 'Quân cờ này nằm ở vị trí phong thủy cực kỳ đắc địa luôn! 🏡'",
            "Teio: 'Trainer chuẩn bị tâm lý nhận vé phạt chép phạt vì dám thua em đi! 📝'",
            "Teio: 'Em lướt qua bàn cờ nhẹ nhàng như một cơn gió mùa thu! 🍃'",
            "Teio: 'Sức mạnh của ý chí bất bại đang dồn hết vào nước đi này! 💪'",
            "Teio: 'Trainer cẩn thận chân tay nha, cờ của em sắc lắm đấy! ✂️'",
            "Teio: 'Một bước đi tinh tế khẳng định vị thế nữ hoàng đường đua! 👑'",
            "Teio: 'Em thắng thế một cách vô cùng thuyết phục luôn rồi nhé! 🏆'"
        ]

        if event_type == "human_move":
            msg = random.choice(human_comments)
        elif event_type == "ai_move":
            msg = random.choice(ai_comments)
        else:
            msg = ""
        self.comment_lbl.configure(text=msg)

    def human_move(self, idx):
        if self.board[idx] == "" and not self.game_over:
            self.board[idx] = self.human
            self.buttons[idx].configure(text=self.human, text_color="#D81B60")
            
            if self.check_win(self.board, self.human):
                self.end_game("win")
                return
            elif "" not in self.board:
                self.end_game("draw")
                return

            self.update_commentary("human_move")
            self.after(300, self.ai_move)

    def ai_move(self):
        if self.game_over:
            return

        best_move = self.find_best_move()
        if best_move is not None:
            self.board[best_move] = self.ai
            self.buttons[best_move].configure(text=self.ai, text_color="#1E88E5")

            if self.check_win(self.board, self.ai):
                self.end_game("lose")
                return
            elif "" not in self.board:
                self.end_game("draw")
                return

            self.update_commentary("ai_move")

    def find_best_move(self):
        empty_cells = [i for i, cell in enumerate(self.board) if cell == ""]
        if not empty_cells:
            return None

        for idx in empty_cells:
            self.board[idx] = self.ai
            if self.check_win(self.board, self.ai):
                self.board[idx] = ""
                return idx
            self.board[idx] = ""

        for idx in empty_cells:
            self.board[idx] = self.human
            if self.check_win(self.board, self.human):
                self.board[idx] = ""
                return idx
            self.board[idx] = ""

        best_score = -1
        best_moves = []

        for idx in empty_cells:
            score = self.evaluate_cell(idx, self.ai) + self.evaluate_cell(idx, self.human) * 0.95
            if score > best_score:
                best_score = score
                best_moves = [idx]
            elif score == best_score:
                best_moves.append(idx)

        return random.choice(best_moves) if best_moves else random.choice(empty_cells)

    def evaluate_cell(self, idx, mark):
        r, c = divmod(idx, self.size)
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        score = 0
        for dr, dc in directions:
            count = 0
            for step in range(1, 5):
                nr, nc = r + dr * step, c + dc * step
                if 0 <= nr < self.size and 0 <= nc < self.size:
                    if self.board[nr * self.size + nc] == mark:
                        count += 1
                    else:
                        break
                else:
                    break
            for step in range(1, 5):
                nr, nc = r - dr * step, c - dc * step
                if 0 <= nr < self.size and 0 <= nc < self.size:
                    if self.board[nr * self.size + nc] == mark:
                        count += 1
                    else:
                        break
                else:
                    break
            score += count * count
        return score

    def check_win(self, b, mark):
        directions = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for r in range(self.size):
            for c in range(self.size):
                if b[r * self.size + c] == mark:
                    for dr, dc in directions:
                        win = True
                        for step in range(1, self.win_streak):
                            nr, nc = r + dr * step, c + dc * step
                            if not (0 <= nr < self.size and 0 <= nc < self.size) or b[nr * self.size + nc] != mark:
                                win = False
                                break
                        if win:
                            return True
        return False

    def end_game(self, result):
        self.game_over = True
        
        # Kho tàng 20+ kiểu thoại kết thúc cho mỗi trường hợp (Thắng - Thua - Hòa)
        win_end_comments = [
            "Teio: 'Huhu... Trainer đánh đỉnh quá! Em thua tâm phục khẩu phục trên bàn 10x10 rồi! 😭'",
            "Teio: 'Oa oà... Thua mất tiêu rồi! Trainer gian lận hay do Trainer quá giỏi thế hả? 🥺'",
            "Teio: 'Em phục sát đất luôn á! Trainer chính là Bá Vương cờ caro thực thụ rồi! 🏆'",
            "Teio: 'Hổng chịu đâu! Lần sau em sẽ phục thù, không nhường Trainer nữa đâu nhé! 😤'",
            "Teio: 'Trận thua này đau đớn quá... Nhưng vì là Trainer nên em bỏ qua đấy! 💖'",
            "Teio: 'Trainer thắng đẹp lắm! Em sẽ ghi nhận trận thua này vào lịch sử học viện! 📜'",
            "Teio: 'Tay nghề lập trình giỏi mà đánh cờ cũng bá đạo nữa, em chịu thua rồi! 🙇‍♀️'",
            "Teio: 'Thôi chết, em bị Trainer lừa ở những nước cuối rồi! Đỉnh quá đi! 🌟'",
            "Teio: 'Một ván thua tâm phục khẩu phục! Trainer khao em bánh tart cà rốt đi nào! 🥕'",
            "Teio: 'Em khóc ngất trên cành quất đây... Trainer dỗ em nhanh lên! 😭💕'",
            "Teio: 'Trainer chơi ác ghê gớm, dồn ép em không thở được luôn á! 😱'",
            "Teio: 'Thôi được rồi, hôm nay Trainer nhận giải quán quân, ngày mai tới lượt em! 🥇'",
            "Teio: 'Trận đấu quá tuyệt vời! Em tuy thua nhưng học hỏi được khối thứ từ Trainer! 📚'",
            "Teio: 'Huhu phồng má hờn dỗi... Đáng lẽ em phải thắng mới đúng chứ bộ! 😾'",
            "Teio: 'Trainer giỏi quá làm em ngưỡng mộ muốn xỉu lên xỉu xuống luôn nè! 😍'",
            "Teio: 'Thua dưới tay Trainer thì em không có gì phải hối hận cả! 🛡️'",
            "Teio: 'Hẹn Trainer ván sau nhé, lúc đó em sẽ bật mode siêu سايヤ人 luôn cho coi! 🔥'",
            "Teio: 'Bái phục bái phục! Trainer nhận của em một lạy vì quá siêu nhân! 🙇‍♂️'",
            "Teio: 'Em cạn kiệt thể lực rồi... Lỗi tại Trainer đánh hiểm quá đó! 🍼'",
            "Teio: 'Dù thua nhưng em vẫn là Uma Musume đáng yêu nhất của Trainer mà, đúng hông? ✨'"
        ]

        lose_end_comments = [
            "Teio: 'Hahaha! Thắng rồi! Nối đủ 5 quân trước là nghệ thuật đỉnh cao của Teio! 👑✨'",
            "Teio: 'Đã bảo là đường đua này thuộc về em cơ mà! Trainer thấy cú bứt phá chưa? 😎'",
            "Teio: 'Yeahhh! Thắng oanh liệt luôn! Trainer chuẩn bị nhận hình phạt chép phạt đi nha! 📝'",
            "Teio: 'Đế vương miền Đông chưa bao giờ biết mùi thất bại trên bàn cờ này! 🏇'",
            "Teio: 'Quá đã! Trận thắng này phải thưởng ngay cho em 3 phần bánh tart cà rốt! 🥕🥕🥕'",
            "Teio: 'Trainer cố gắng lắm rồi nhưng tiếc quá, em nhanh chân về đích trước nhé! 🏁'",
            "Teio: 'Hahaha, chiến thắng ngọt ngào quá đi mất! Cảm ơn Trainer đã nhường em nha! 🍯'",
            "Teio: 'Nghệ thuật giăng bẫy đỉnh cao của em đã phát huy tác dụng tuyệt đối! 🎯'",
            "Teio: 'Thấy sức mạnh của Teio Step chưa hả Trainer? Quá khủng khiếp đúng không! ⚡'",
            "Teio: 'Em đã bảo là đừng có đùa với Uma Musume thiên tài mà lại không nghe cơ! 😌'",
            "Teio: 'Trận chiến kết thúc và chiếc cúp vô địch thuộc về Teio xinh đẹp! 🏆'",
            "Teio: 'Trainer thua cuộc tâm phục khẩu phục chưa nào? Mau nịnh em nhanh lên! 💖'",
            "Teio: 'Hahaha, vui quá đi mất! Hôm nay em phải nhảy múa ăn mừng mới được! 💃'",
            "Teio: 'Chiến thắng này dành tặng riêng cho Trainer như một động lực học tập nhé! 🎁'",
            "Teio: 'Em vừa có một màn biểu diễn chiến thuật không tì vết luôn á! 🌟'",
            "Teio: 'Thôi đừng buồn nha Trainer, thua dưới tay em là vinh dự đấy biết không! 😉'",
            "Teio: 'Bàn cờ 10x10 đã chính thức bị em thống trị hoàn toàn! 🌐'",
            "Teio: 'Quá tuyệt vời! Thêm một huy hoàng nữa được ghi vào sự nghiệp của Teio! 🏅'",
            "Teio: 'Trainer phục sát đất chưa? Thôi đứng dậy đi uống nước mật ong với em nào! 🥤'",
            "Teio: 'Chiến thắng thuộc về phe chính nghĩa và thông minh! Chính là em đó! ✨'"
        ]

        draw_end_comments = [
            "Teio: 'Bất phân thắng bại! Đúng là đối thủ ngang tài ngang sức với Teio! 🤝'",
            "Teio: 'Hòa nhau thế này thì ấm ức ghê, phải đấu lại ngay lập tức thôi! 🔂'",
            "Teio: 'Kẻ tám lạng người nửa cân, không ai chịu nhường ai luôn á! ⚖️'",
            "Teio: 'Trận đấu căng não đến phút chót mà kết quả hòa thì hơi tiếc nhỉ? 😮‍💨'",
            "Teio: 'Thôi thì huề cả làng, hai ta cùng nhận huy danh danh dự nhé! 🎖️'",
            "Teio: 'Không ngờ Trainer lại thủ hòa được với em đấy, đáng khen đáng khen! 👏'",
            "Teio: 'Bàn cờ chật ních quân mà không phân định thắng thua, kỳ ghê ta! 🧩'",
            "Teio: 'Trận hòa này chứng tỏ chúng ta sinh ra để dành cho nhau làm đồng đội! 🥰'",
            "Teio: 'Hòa rồi nhé! Lần sau em sẽ quyết tâm phân định thắng thua cho bằng được! 💪'",
            "Teio: 'Ngang sức ngang tài thế này mới thú vị chứ lị! Thích thật đấy! 🔥'",
            "Teio: 'Cả hai mỏi tay luôn mà kết quả vẫn hoàn hòa. Cười xỉu! 😂'",
            "Teio: 'Một trận đấu cân bằng hoàn hảo như được lập trình sẵn! 💻'",
            "Teio: 'Trainer và em hòa nhau nghĩa là cả hai cùng chiến thắng trong lòng khán giả! 🌟'",
            "Teio: 'Hòa thì hòa, nhưng em vẫn muốn đấu lại một ván nữa ngay bây giờ! 🔄'",
            "Teio: 'Kẻ kỳ tài gặp nhau là đây chứ đâu! Không ai chịu thua ai cả! ⚔️'",
            "Teio: 'Hết ô trống để đi luôn rồi, tính ra chúng ta siêu thật đấy chứ! 🧠'",
            "Teio: 'Trận hòa hòa vi quý! Trainer thấy vui không nào? 😊'",
            "Teio: 'Không phân thắng bại, coi như em cho Trainer nợ trận thắng này nhé! 📝'",
            "Teio: 'Đỉnh cao của giằng co chính là kết quả hòa mãn nhãn thế này! 🎇'",
            "Teio: 'Thôi bắt tay làm hòa nào đồng chí Trainer vĩ đại ơi! 🤝✨'"
        ]

        if result == "win":
            msg = random.choice(win_end_comments)
        elif result == "lose":
            msg = random.choice(lose_end_comments)
        else:
            msg = random.choice(draw_end_comments)

        self.comment_lbl.configure(text=msg)
        self.show_victory_popup(result, msg)

    # ================= POPUP KẾT QUẢ HOÀNH TRÁNG =================
    def show_victory_popup(self, result, end_comment):
        popup = ctk.CTkToplevel(self)
        popup.title("KẾT QUẢ TRẬN ĐẤU 10x10")
        popup.geometry("340x360")
        popup.grab_set()
        popup.resizable(False, False)

        if result == "win":
            title_text = "🎉 TRAINER CHIẾN THẮNG!"
            status_color = "#2ecc71"
        elif result == "lose":
            title_text = "👑 TEIO CHIẾN THẮNG!"
            status_color = "#e74c3c"
        else:
            title_text = "🤝 BẤT PHÂN THẮNG BẠI!"
            status_color = "#f39c12"

        card = ctk.CTkFrame(popup, fg_color=("#F8F9FA", "#1E1E1E"), corner_radius=12)
        card.pack(fill="both", expand=True, padx=10, pady=10)

        if self.avatar_img:
            img_lbl = ctk.CTkLabel(card, image=self.avatar_img, text="")
        else:
            img_lbl = ctk.CTkLabel(card, text="🏆", font=("Arial", 40))
        img_lbl.pack(pady=(12, 4))

        t_lbl = ctk.CTkLabel(card, text=title_text, font=("Arial", 13, "bold"), text_color=status_color)
        t_lbl.pack(pady=4)

        # Hiển thị câu thoại kết thúc đặc sắc
        s_lbl = ctk.CTkLabel(card, text=end_comment, font=("Arial", 10, "italic"), wraplength=280, justify="center")
        s_lbl.pack(pady=6, padx=10)

        btn_replay = ctk.CTkButton(
            card, text="🔄 Đấu Lại Ván 10x10 Mới", font=("Arial", 11, "bold"),
            fg_color=status_color, height=36,
            command=lambda: [popup.destroy(), self.reset_game()]
        )
        btn_replay.pack(pady=10, fill="x", padx=20)

    def reset_game(self):
        self.board = [""] * (self.size * self.size)
        self.game_over = False
        for btn in self.buttons:
            btn.configure(text="", fg_color=("#FFFFFF", "#2E3440"))
        self.comment_lbl.configure(text="Teio: 'Ván đấu 10x10 mới bắt đầu! Lần này em sẽ không nhường nữa đâu nhé! 🚀'")